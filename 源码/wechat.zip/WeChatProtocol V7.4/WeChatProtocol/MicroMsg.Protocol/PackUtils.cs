namespace MicroMsg.Protocol
{
    using System;
    //δʹ����
    public class PackUtils
    {
        public static byte[] hex2byte(byte[] b)
        {
            return null;
        }

        public static byte[] str2ascii(string s)
        {
            return null;
        }
    }
}

