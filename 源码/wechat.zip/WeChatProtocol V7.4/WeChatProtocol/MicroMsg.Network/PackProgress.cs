namespace MicroMsg.Network
{
    using System;

    public class PackProgress
    {
        public int lengthReceived;
        public int lengthSent;
    }
}

