namespace MicroMsg.UI.Page
{
    using System;

    internal enum ReceiverType
    {
        BCC_RECEIVER = 3,
        CC_RECEIVER = 2,
        TO_RECEIVER = 1
    }
}

