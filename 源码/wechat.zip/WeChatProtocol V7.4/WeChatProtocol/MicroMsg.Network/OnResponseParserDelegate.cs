namespace MicroMsg.Network
{
    using System;
    

    public delegate object OnResponseParserDelegate(SessionPack sessionPack);
}

