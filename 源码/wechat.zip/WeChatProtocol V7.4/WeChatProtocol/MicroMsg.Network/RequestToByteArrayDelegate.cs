namespace MicroMsg.Network
{
    using System;
    

    public delegate byte[] RequestToByteArrayDelegate(object request);
}

