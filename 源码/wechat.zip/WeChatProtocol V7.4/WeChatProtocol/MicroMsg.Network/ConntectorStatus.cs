namespace MicroMsg.Network
{
    using System;

    public enum ConntectorStatus
    {
        Connected,
        Connecting,
        Disconnect
    }
}

