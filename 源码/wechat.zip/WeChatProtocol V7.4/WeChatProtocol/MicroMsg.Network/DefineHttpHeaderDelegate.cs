namespace MicroMsg.Network
{
    using System;
    using System.Net;
    

    public delegate void DefineHttpHeaderDelegate(HttpWebRequest request);
}

