namespace MicroMsg.Network
{
    //using MicroMsg.Storage;
    using System;

    public class ServerAddress
    {
        public byte[] bytesIP;
        public uint nData;
        public uint nPort;
        public uint nType;
    }
}

