namespace MicroMsg.Network
{
    using System;
    

    public delegate void OnHttpReceivedProgressDelegate(int length);
}

