namespace MicroMsg.Network
{
    //using MicroMsg.Storage;
    using System;
    using System.Collections.Generic;

    public class IDCDnsHost
    {
        public List<DNSHostItemInfo> _keep_idcHostList;
    }
}

