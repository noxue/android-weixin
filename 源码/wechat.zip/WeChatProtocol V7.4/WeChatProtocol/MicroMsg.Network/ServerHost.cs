namespace MicroMsg.Network
{
    //using MicroMsg.Storage;
    using System;
    using System.Collections.Generic;

    
    public class ServerHost
    {
        public List<ServerAddress> addrList = new List<ServerAddress>();
    }
}

