namespace MicroMsg.Network
{
   // using MicroMsg.Storage;
    using System;


    public class DNSHostItemInfo
    {
        public string _keep_origin;
        public string _keep_substitute;
    }
}

