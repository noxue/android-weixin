namespace MicroMsg.Network
{
    using System;
    

    public delegate void SessionPackCompletedDelegate(object sender, PackEventArgs e);
}

