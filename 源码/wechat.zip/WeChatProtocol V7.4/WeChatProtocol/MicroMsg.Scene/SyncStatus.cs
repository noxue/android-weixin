namespace MicroMsg.Scene
{
    using System;

    public enum SyncStatus
    {
        syncEnd,
        syncBegin,
        syncErr
    }
}

