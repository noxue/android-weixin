namespace MicroMsg.Scene
{
    using System;

    public enum RecvMsgStatus
    {
        isRecvVoice = 2,
        isSynNow = 1
    }
}

