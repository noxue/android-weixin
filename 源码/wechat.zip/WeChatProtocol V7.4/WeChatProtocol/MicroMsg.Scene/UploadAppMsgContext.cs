namespace MicroMsg.Scene
{
    using MicroMsg.Storage;
    using System;

    public class UploadAppMsgContext
    {
        public ChatMsg mMsg;
        public MsgTrans mTrans;
    }
}

