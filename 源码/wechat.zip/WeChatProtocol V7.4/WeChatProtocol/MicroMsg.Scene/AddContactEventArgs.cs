namespace MicroMsg.Scene
{
    using MicroMsg.Protocol;
    using System;

    public class AddContactEventArgs
    {
        public AddContactScene lastScene;
        public RetConst result;
        public string toUserName;
    }
}

