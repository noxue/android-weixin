namespace MicroMsg.Scene
{
    using System;
    

    public delegate void onSendAppMsgFinished(UploadAppMsgContext context);
}

