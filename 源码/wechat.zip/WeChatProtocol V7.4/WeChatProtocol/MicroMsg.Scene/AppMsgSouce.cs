namespace MicroMsg.Scene
{
    using System;

    public enum AppMsgSouce
    {
        MM_APPMSG_3RD = 2,
        MM_APPMSG_FORWARD = 3,
        MM_APPMSG_WEIXIN = 1
    }
}

