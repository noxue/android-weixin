namespace MicroMsg.Scene
{
    using System;

    public enum GetA8KeyOpCode
    {
        MMGETA8KEY_OPENAPI = 1,
        MMGETA8KEY_QZONE = 3,
        MMGETA8KEY_REDIRECT = 2
    }
}

