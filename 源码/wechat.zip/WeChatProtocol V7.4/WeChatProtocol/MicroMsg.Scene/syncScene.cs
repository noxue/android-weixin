namespace MicroMsg.Scene
{
    using System;

    public enum syncScene
    {
        MM_NEWSYNC_SCENE_AFTERINIT = 5,
        MM_NEWSYNC_SCENE_BG2FG = 3,
        MM_NEWSYNC_SCENE_CONTINUEFLAG = 6,
        MM_NEWSYNC_SCENE_NOTIFY = 1,
        MM_NEWSYNC_SCENE_OTHER = 7,
        MM_NEWSYNC_SCENE_PROCESSSTART = 4,
        MM_NEWSYNC_SCENE_TIMER = 2
    }
}

