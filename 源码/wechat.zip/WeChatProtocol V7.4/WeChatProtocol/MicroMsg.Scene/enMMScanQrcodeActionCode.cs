namespace MicroMsg.Scene
{
    using System;

    public enum enMMScanQrcodeActionCode
    {
        MMSCAN_QRCODE_A8KEY,
        MMSCAN_QRCODE_TEXT,
        MMSCAN_QRCODE_WEBVIEW,
        MMSCAN_QRCODE_APP,
        MMSCAN_QRCODE_PROFILE,
        MMSCAN_QRCODE_PLUGIN,
        MMSCAN_QRCODE_SPECIAL_WEBVIEW,
        MMSCAN_QRCODE_WEBVIEW_NO_NOTICE,
        MMSCAN_QRCODE_VCARD,
        MMSCAN_QRCODE_JUMP
    }
}

