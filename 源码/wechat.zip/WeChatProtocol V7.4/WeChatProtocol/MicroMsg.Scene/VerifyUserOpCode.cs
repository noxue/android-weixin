namespace MicroMsg.Scene
{
    using System;

    public enum VerifyUserOpCode
    {
        MM_VERIFYUSER_ADDCONTACT = 1,
        MM_VERIFYUSER_SENDREQUEST = 2,
        MM_VERIFYUSER_VERIFYOK = 3,
        MM_VERIFYUSER_VERIFYREJECT = 4
    }
}

