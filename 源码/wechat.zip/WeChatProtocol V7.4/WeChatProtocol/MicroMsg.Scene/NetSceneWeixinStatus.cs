namespace MicroMsg.Scene
{
    using System;

    public class NetSceneWeixinStatus
    {
        public bool isShakeBookMarkBind;
        public bool isShakeTranImgActive;
        public bool isShakeTranImgBind;
        public bool isWebWeiXinLogin;
    }
}

