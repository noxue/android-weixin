namespace MicroMsg.Plugin
{
    using MicroMsg.Storage;
    using System;
    using System.Collections.Generic;

    
    public class PluginMetaMap
    {
        public Dictionary<string, PluginMetaInfo> mapPluginMetaInfo = new Dictionary<string, PluginMetaInfo>();
    }
}

