namespace MicroMsg.Plugin
{
    using System;

    public enum MainTabIndex
    {
        AddFriendList = 8,
        ContactTab = 2,
        ConversationTab = 1,
        FindFriendTab = 4
    }
}

