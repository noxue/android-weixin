namespace MicroMsg.Plugin
{
    using System;

    public enum InstallMode
    {
        UserInstall,
        DefaultInstall,
        SyncInstall
    }
}

