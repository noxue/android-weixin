namespace MicroMsg.Plugin
{
    using MicroMsg.Storage;
    using System;
    using System.Collections.Generic;

    
    public class ExternPluginList
    {
        public List<string> pluginClassName = new List<string>();
    }
}

