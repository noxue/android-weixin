﻿namespace WeChatProtocol
{
    partial class sendForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rb_QueryRed = new System.Windows.Forms.RadioButton();
            this.rb_VerifyPayPassword = new System.Windows.Forms.RadioButton();
            this.rb_open = new System.Windows.Forms.RadioButton();
            this.rb_SnsDetail = new System.Windows.Forms.RadioButton();
            this.rb_delsns = new System.Windows.Forms.RadioButton();
            this.rb_delComment = new System.Windows.Forms.RadioButton();
            this.rb_like = new System.Windows.Forms.RadioButton();
            this.rb_cndvideo = new System.Windows.Forms.RadioButton();
            this.rb_video = new System.Windows.Forms.RadioButton();
            this.rb_QuitChatRoom = new System.Windows.Forms.RadioButton();
            this.rb_delAllFriends = new System.Windows.Forms.RadioButton();
            this.rb_SearchContact = new System.Windows.Forms.RadioButton();
            this.rb_addroomuser = new System.Windows.Forms.RadioButton();
            this.rb_getkey = new System.Windows.Forms.RadioButton();
            this.rb_GetContact = new System.Windows.Forms.RadioButton();
            this.rb_loginbyphone = new System.Windows.Forms.RadioButton();
            this.rb_delContact = new System.Windows.Forms.RadioButton();
            this.rb_sns = new System.Windows.Forms.RadioButton();
            this.rb_card = new System.Windows.Forms.RadioButton();
            this.rb_ImgMsg = new System.Windows.Forms.RadioButton();
            this.rb_LuckyMoneyMsg = new System.Windows.Forms.RadioButton();
            this.rb_AppMsg = new System.Windows.Forms.RadioButton();
            this.rb_VideMsg = new System.Windows.Forms.RadioButton();
            this.rb_VoiceMsg = new System.Windows.Forms.RadioButton();
            this.rb_TextMsg = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.pB_ShowQrcode = new System.Windows.Forms.PictureBox();
            this.btn_GetLoginQrcode = new System.Windows.Forms.Button();
            this.lab_ShowMsg = new System.Windows.Forms.Label();
            this.tb_Contents = new System.Windows.Forms.TextBox();
            this.tb_toUsername = new System.Windows.Forms.TextBox();
            this.lable2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_SendBuf = new System.Windows.Forms.Button();
            this.btn_AutoAuth = new System.Windows.Forms.Button();
            this.btn_SendALL = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_HB_CONTACT = new System.Windows.Forms.TextBox();
            this.tb_JMP_URL = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pB_ShowQrcode)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Location = new System.Drawing.Point(648, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(284, 467);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Console";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rb_QueryRed);
            this.groupBox2.Controls.Add(this.rb_VerifyPayPassword);
            this.groupBox2.Controls.Add(this.rb_open);
            this.groupBox2.Controls.Add(this.rb_SnsDetail);
            this.groupBox2.Controls.Add(this.rb_delsns);
            this.groupBox2.Controls.Add(this.rb_delComment);
            this.groupBox2.Controls.Add(this.rb_like);
            this.groupBox2.Controls.Add(this.rb_cndvideo);
            this.groupBox2.Controls.Add(this.rb_video);
            this.groupBox2.Controls.Add(this.rb_QuitChatRoom);
            this.groupBox2.Controls.Add(this.rb_delAllFriends);
            this.groupBox2.Controls.Add(this.rb_SearchContact);
            this.groupBox2.Controls.Add(this.rb_addroomuser);
            this.groupBox2.Controls.Add(this.rb_getkey);
            this.groupBox2.Controls.Add(this.rb_GetContact);
            this.groupBox2.Controls.Add(this.rb_loginbyphone);
            this.groupBox2.Controls.Add(this.rb_delContact);
            this.groupBox2.Controls.Add(this.rb_sns);
            this.groupBox2.Controls.Add(this.rb_card);
            this.groupBox2.Controls.Add(this.rb_ImgMsg);
            this.groupBox2.Controls.Add(this.rb_LuckyMoneyMsg);
            this.groupBox2.Controls.Add(this.rb_AppMsg);
            this.groupBox2.Controls.Add(this.rb_VideMsg);
            this.groupBox2.Controls.Add(this.rb_VoiceMsg);
            this.groupBox2.Controls.Add(this.rb_TextMsg);
            this.groupBox2.Location = new System.Drawing.Point(6, 96);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(265, 329);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "MsgType";
            // 
            // rb_QueryRed
            // 
            this.rb_QueryRed.AutoSize = true;
            this.rb_QueryRed.Location = new System.Drawing.Point(148, 288);
            this.rb_QueryRed.Name = "rb_QueryRed";
            this.rb_QueryRed.Size = new System.Drawing.Size(89, 16);
            this.rb_QueryRed.TabIndex = 24;
            this.rb_QueryRed.TabStop = true;
            this.rb_QueryRed.Text = "rb_QueryRed";
            this.rb_QueryRed.UseVisualStyleBackColor = true;
            // 
            // rb_VerifyPayPassword
            // 
            this.rb_VerifyPayPassword.AutoSize = true;
            this.rb_VerifyPayPassword.Location = new System.Drawing.Point(147, 259);
            this.rb_VerifyPayPassword.Name = "rb_VerifyPayPassword";
            this.rb_VerifyPayPassword.Size = new System.Drawing.Size(125, 16);
            this.rb_VerifyPayPassword.TabIndex = 23;
            this.rb_VerifyPayPassword.TabStop = true;
            this.rb_VerifyPayPassword.Text = "VerifyPayPassword";
            this.rb_VerifyPayPassword.UseVisualStyleBackColor = true;
            // 
            // rb_open
            // 
            this.rb_open.AutoSize = true;
            this.rb_open.Location = new System.Drawing.Point(26, 288);
            this.rb_open.Name = "rb_open";
            this.rb_open.Size = new System.Drawing.Size(101, 16);
            this.rb_open.TabIndex = 22;
            this.rb_open.TabStop = true;
            this.rb_open.Text = "openLuckMoney";
            this.rb_open.UseVisualStyleBackColor = true;
            // 
            // rb_SnsDetail
            // 
            this.rb_SnsDetail.AutoSize = true;
            this.rb_SnsDetail.Location = new System.Drawing.Point(147, 237);
            this.rb_SnsDetail.Name = "rb_SnsDetail";
            this.rb_SnsDetail.Size = new System.Drawing.Size(95, 16);
            this.rb_SnsDetail.TabIndex = 21;
            this.rb_SnsDetail.TabStop = true;
            this.rb_SnsDetail.Text = "getSnsDetail";
            this.rb_SnsDetail.UseVisualStyleBackColor = true;
            // 
            // rb_delsns
            // 
            this.rb_delsns.AutoSize = true;
            this.rb_delsns.Location = new System.Drawing.Point(27, 254);
            this.rb_delsns.Name = "rb_delsns";
            this.rb_delsns.Size = new System.Drawing.Size(59, 16);
            this.rb_delsns.TabIndex = 20;
            this.rb_delsns.TabStop = true;
            this.rb_delsns.Text = "delsns";
            this.rb_delsns.UseVisualStyleBackColor = true;
            // 
            // rb_delComment
            // 
            this.rb_delComment.AutoSize = true;
            this.rb_delComment.Location = new System.Drawing.Point(147, 215);
            this.rb_delComment.Name = "rb_delComment";
            this.rb_delComment.Size = new System.Drawing.Size(83, 16);
            this.rb_delComment.TabIndex = 19;
            this.rb_delComment.TabStop = true;
            this.rb_delComment.Text = "delComment";
            this.rb_delComment.UseVisualStyleBackColor = true;
            // 
            // rb_like
            // 
            this.rb_like.AutoSize = true;
            this.rb_like.Location = new System.Drawing.Point(27, 233);
            this.rb_like.Name = "rb_like";
            this.rb_like.Size = new System.Drawing.Size(89, 16);
            this.rb_like.TabIndex = 18;
            this.rb_like.TabStop = true;
            this.rb_like.Text = "setLikeFlag";
            this.rb_like.UseVisualStyleBackColor = true;
            // 
            // rb_cndvideo
            // 
            this.rb_cndvideo.AutoSize = true;
            this.rb_cndvideo.Location = new System.Drawing.Point(25, 153);
            this.rb_cndvideo.Name = "rb_cndvideo";
            this.rb_cndvideo.Size = new System.Drawing.Size(107, 16);
            this.rb_cndvideo.TabIndex = 17;
            this.rb_cndvideo.TabStop = true;
            this.rb_cndvideo.Text = "UploadCdnVideo";
            this.rb_cndvideo.UseVisualStyleBackColor = true;
            // 
            // rb_video
            // 
            this.rb_video.AutoSize = true;
            this.rb_video.Location = new System.Drawing.Point(26, 176);
            this.rb_video.Name = "rb_video";
            this.rb_video.Size = new System.Drawing.Size(89, 16);
            this.rb_video.TabIndex = 16;
            this.rb_video.TabStop = true;
            this.rb_video.Text = "UploadVideo";
            this.rb_video.UseVisualStyleBackColor = true;
            // 
            // rb_QuitChatRoom
            // 
            this.rb_QuitChatRoom.AutoSize = true;
            this.rb_QuitChatRoom.Location = new System.Drawing.Point(148, 175);
            this.rb_QuitChatRoom.Name = "rb_QuitChatRoom";
            this.rb_QuitChatRoom.Size = new System.Drawing.Size(95, 16);
            this.rb_QuitChatRoom.TabIndex = 15;
            this.rb_QuitChatRoom.TabStop = true;
            this.rb_QuitChatRoom.Text = "QuitChatRoom";
            this.rb_QuitChatRoom.UseVisualStyleBackColor = true;
            // 
            // rb_delAllFriends
            // 
            this.rb_delAllFriends.AutoSize = true;
            this.rb_delAllFriends.Location = new System.Drawing.Point(148, 193);
            this.rb_delAllFriends.Name = "rb_delAllFriends";
            this.rb_delAllFriends.Size = new System.Drawing.Size(95, 16);
            this.rb_delAllFriends.TabIndex = 14;
            this.rb_delAllFriends.TabStop = true;
            this.rb_delAllFriends.Text = "批量删除好友";
            this.rb_delAllFriends.UseVisualStyleBackColor = true;
            // 
            // rb_SearchContact
            // 
            this.rb_SearchContact.AutoSize = true;
            this.rb_SearchContact.Location = new System.Drawing.Point(26, 194);
            this.rb_SearchContact.Name = "rb_SearchContact";
            this.rb_SearchContact.Size = new System.Drawing.Size(101, 16);
            this.rb_SearchContact.TabIndex = 13;
            this.rb_SearchContact.TabStop = true;
            this.rb_SearchContact.Text = "SearchContact";
            this.rb_SearchContact.UseVisualStyleBackColor = true;
            // 
            // rb_addroomuser
            // 
            this.rb_addroomuser.AutoSize = true;
            this.rb_addroomuser.Location = new System.Drawing.Point(148, 155);
            this.rb_addroomuser.Name = "rb_addroomuser";
            this.rb_addroomuser.Size = new System.Drawing.Size(89, 16);
            this.rb_addroomuser.TabIndex = 12;
            this.rb_addroomuser.TabStop = true;
            this.rb_addroomuser.Text = "AddRoomUser";
            this.rb_addroomuser.UseVisualStyleBackColor = true;
            // 
            // rb_getkey
            // 
            this.rb_getkey.AutoSize = true;
            this.rb_getkey.Location = new System.Drawing.Point(27, 131);
            this.rb_getkey.Name = "rb_getkey";
            this.rb_getkey.Size = new System.Drawing.Size(71, 16);
            this.rb_getkey.TabIndex = 11;
            this.rb_getkey.TabStop = true;
            this.rb_getkey.Text = "GetA8Key";
            this.rb_getkey.UseVisualStyleBackColor = true;
            // 
            // rb_GetContact
            // 
            this.rb_GetContact.AutoSize = true;
            this.rb_GetContact.Location = new System.Drawing.Point(148, 136);
            this.rb_GetContact.Name = "rb_GetContact";
            this.rb_GetContact.Size = new System.Drawing.Size(107, 16);
            this.rb_GetContact.TabIndex = 10;
            this.rb_GetContact.TabStop = true;
            this.rb_GetContact.Text = "GetContactInfo";
            this.rb_GetContact.UseVisualStyleBackColor = true;
            // 
            // rb_loginbyphone
            // 
            this.rb_loginbyphone.AutoSize = true;
            this.rb_loginbyphone.Location = new System.Drawing.Point(26, 111);
            this.rb_loginbyphone.Name = "rb_loginbyphone";
            this.rb_loginbyphone.Size = new System.Drawing.Size(95, 16);
            this.rb_loginbyphone.TabIndex = 9;
            this.rb_loginbyphone.TabStop = true;
            this.rb_loginbyphone.Text = "LoginByPhone";
            this.rb_loginbyphone.UseVisualStyleBackColor = true;
            // 
            // rb_delContact
            // 
            this.rb_delContact.AutoSize = true;
            this.rb_delContact.Location = new System.Drawing.Point(148, 114);
            this.rb_delContact.Name = "rb_delContact";
            this.rb_delContact.Size = new System.Drawing.Size(83, 16);
            this.rb_delContact.TabIndex = 8;
            this.rb_delContact.TabStop = true;
            this.rb_delContact.Text = "delContact";
            this.rb_delContact.UseVisualStyleBackColor = true;
            // 
            // rb_sns
            // 
            this.rb_sns.AutoSize = true;
            this.rb_sns.Location = new System.Drawing.Point(148, 93);
            this.rb_sns.Name = "rb_sns";
            this.rb_sns.Size = new System.Drawing.Size(95, 16);
            this.rb_sns.TabIndex = 7;
            this.rb_sns.TabStop = true;
            this.rb_sns.Text = "GetSnsCircle";
            this.rb_sns.UseVisualStyleBackColor = true;
            // 
            // rb_card
            // 
            this.rb_card.AutoSize = true;
            this.rb_card.Location = new System.Drawing.Point(148, 70);
            this.rb_card.Name = "rb_card";
            this.rb_card.Size = new System.Drawing.Size(65, 16);
            this.rb_card.TabIndex = 6;
            this.rb_card.TabStop = true;
            this.rb_card.Text = "CardMsg";
            this.rb_card.UseVisualStyleBackColor = true;
            // 
            // rb_ImgMsg
            // 
            this.rb_ImgMsg.AutoSize = true;
            this.rb_ImgMsg.Location = new System.Drawing.Point(148, 48);
            this.rb_ImgMsg.Name = "rb_ImgMsg";
            this.rb_ImgMsg.Size = new System.Drawing.Size(59, 16);
            this.rb_ImgMsg.TabIndex = 5;
            this.rb_ImgMsg.TabStop = true;
            this.rb_ImgMsg.Text = "ImgMsg";
            this.rb_ImgMsg.UseVisualStyleBackColor = true;
            // 
            // rb_LuckyMoneyMsg
            // 
            this.rb_LuckyMoneyMsg.AutoSize = true;
            this.rb_LuckyMoneyMsg.Location = new System.Drawing.Point(147, 26);
            this.rb_LuckyMoneyMsg.Name = "rb_LuckyMoneyMsg";
            this.rb_LuckyMoneyMsg.Size = new System.Drawing.Size(101, 16);
            this.rb_LuckyMoneyMsg.TabIndex = 4;
            this.rb_LuckyMoneyMsg.TabStop = true;
            this.rb_LuckyMoneyMsg.Text = "LuckyMoneyMsg";
            this.rb_LuckyMoneyMsg.UseVisualStyleBackColor = true;
            // 
            // rb_AppMsg
            // 
            this.rb_AppMsg.AutoSize = true;
            this.rb_AppMsg.Location = new System.Drawing.Point(26, 90);
            this.rb_AppMsg.Name = "rb_AppMsg";
            this.rb_AppMsg.Size = new System.Drawing.Size(59, 16);
            this.rb_AppMsg.TabIndex = 3;
            this.rb_AppMsg.TabStop = true;
            this.rb_AppMsg.Text = "AppMsg";
            this.rb_AppMsg.UseVisualStyleBackColor = true;
            // 
            // rb_VideMsg
            // 
            this.rb_VideMsg.AutoSize = true;
            this.rb_VideMsg.Location = new System.Drawing.Point(26, 69);
            this.rb_VideMsg.Name = "rb_VideMsg";
            this.rb_VideMsg.Size = new System.Drawing.Size(71, 16);
            this.rb_VideMsg.TabIndex = 2;
            this.rb_VideMsg.TabStop = true;
            this.rb_VideMsg.Text = "VideoMsg";
            this.rb_VideMsg.UseVisualStyleBackColor = true;
            // 
            // rb_VoiceMsg
            // 
            this.rb_VoiceMsg.AutoSize = true;
            this.rb_VoiceMsg.Location = new System.Drawing.Point(26, 48);
            this.rb_VoiceMsg.Name = "rb_VoiceMsg";
            this.rb_VoiceMsg.Size = new System.Drawing.Size(71, 16);
            this.rb_VoiceMsg.TabIndex = 1;
            this.rb_VoiceMsg.TabStop = true;
            this.rb_VoiceMsg.Text = "VoiceMsg";
            this.rb_VoiceMsg.UseVisualStyleBackColor = true;
            // 
            // rb_TextMsg
            // 
            this.rb_TextMsg.AutoSize = true;
            this.rb_TextMsg.Location = new System.Drawing.Point(26, 27);
            this.rb_TextMsg.Name = "rb_TextMsg";
            this.rb_TextMsg.Size = new System.Drawing.Size(65, 16);
            this.rb_TextMsg.TabIndex = 0;
            this.rb_TextMsg.TabStop = true;
            this.rb_TextMsg.Text = "TextMsg";
            this.rb_TextMsg.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(74, 431);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(93, 30);
            this.button1.TabIndex = 8;
            this.button1.Text = "Send";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pB_ShowQrcode
            // 
            this.pB_ShowQrcode.Location = new System.Drawing.Point(65, 36);
            this.pB_ShowQrcode.Name = "pB_ShowQrcode";
            this.pB_ShowQrcode.Size = new System.Drawing.Size(202, 199);
            this.pB_ShowQrcode.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pB_ShowQrcode.TabIndex = 1;
            this.pB_ShowQrcode.TabStop = false;
            // 
            // btn_GetLoginQrcode
            // 
            this.btn_GetLoginQrcode.Location = new System.Drawing.Point(65, 283);
            this.btn_GetLoginQrcode.Name = "btn_GetLoginQrcode";
            this.btn_GetLoginQrcode.Size = new System.Drawing.Size(202, 30);
            this.btn_GetLoginQrcode.TabIndex = 9;
            this.btn_GetLoginQrcode.Text = "获取二维码";
            this.btn_GetLoginQrcode.UseVisualStyleBackColor = true;
            this.btn_GetLoginQrcode.Click += new System.EventHandler(this.btn_GetLoginQrcode_Click);
            // 
            // lab_ShowMsg
            // 
            this.lab_ShowMsg.Location = new System.Drawing.Point(63, 246);
            this.lab_ShowMsg.Name = "lab_ShowMsg";
            this.lab_ShowMsg.Size = new System.Drawing.Size(204, 29);
            this.lab_ShowMsg.TabIndex = 10;
            this.lab_ShowMsg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tb_Contents
            // 
            this.tb_Contents.Location = new System.Drawing.Point(323, 87);
            this.tb_Contents.MaxLength = 0;
            this.tb_Contents.Multiline = true;
            this.tb_Contents.Name = "tb_Contents";
            this.tb_Contents.Size = new System.Drawing.Size(204, 179);
            this.tb_Contents.TabIndex = 12;
            // 
            // tb_toUsername
            // 
            this.tb_toUsername.Location = new System.Drawing.Point(398, 33);
            this.tb_toUsername.MaxLength = 0;
            this.tb_toUsername.Name = "tb_toUsername";
            this.tb_toUsername.Size = new System.Drawing.Size(114, 21);
            this.tb_toUsername.TabIndex = 11;
            // 
            // lable2
            // 
            this.lable2.AutoSize = true;
            this.lable2.Location = new System.Drawing.Point(326, 63);
            this.lable2.Name = "lable2";
            this.lable2.Size = new System.Drawing.Size(59, 12);
            this.lable2.TabIndex = 14;
            this.lable2.Text = "Contents:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(321, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 12);
            this.label1.TabIndex = 13;
            this.label1.Text = "toUsername:";
            // 
            // btn_SendBuf
            // 
            this.btn_SendBuf.Location = new System.Drawing.Point(325, 283);
            this.btn_SendBuf.Name = "btn_SendBuf";
            this.btn_SendBuf.Size = new System.Drawing.Size(202, 30);
            this.btn_SendBuf.TabIndex = 15;
            this.btn_SendBuf.Text = "SendBuf";
            this.btn_SendBuf.UseVisualStyleBackColor = true;
            this.btn_SendBuf.Click += new System.EventHandler(this.btn_SendBuf_Click);
            // 
            // btn_AutoAuth
            // 
            this.btn_AutoAuth.Location = new System.Drawing.Point(325, 320);
            this.btn_AutoAuth.Name = "btn_AutoAuth";
            this.btn_AutoAuth.Size = new System.Drawing.Size(202, 30);
            this.btn_AutoAuth.TabIndex = 16;
            this.btn_AutoAuth.Text = "AutoAuth";
            this.btn_AutoAuth.UseVisualStyleBackColor = true;
            this.btn_AutoAuth.Click += new System.EventHandler(this.btn_AutoAuth_Click);
            // 
            // btn_SendALL
            // 
            this.btn_SendALL.Location = new System.Drawing.Point(55, 407);
            this.btn_SendALL.Name = "btn_SendALL";
            this.btn_SendALL.Size = new System.Drawing.Size(202, 30);
            this.btn_SendALL.TabIndex = 17;
            this.btn_SendALL.Text = "SendALL";
            this.btn_SendALL.UseVisualStyleBackColor = true;
            this.btn_SendALL.Click += new System.EventHandler(this.btn_SendALL_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(63, 328);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 12);
            this.label2.TabIndex = 18;
            this.label2.Text = "红包语:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(59, 359);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 12);
            this.label3.TabIndex = 19;
            this.label3.Text = "红包链接:";
            // 
            // tb_HB_CONTACT
            // 
            this.tb_HB_CONTACT.Location = new System.Drawing.Point(120, 320);
            this.tb_HB_CONTACT.MaxLength = 0;
            this.tb_HB_CONTACT.Name = "tb_HB_CONTACT";
            this.tb_HB_CONTACT.Size = new System.Drawing.Size(114, 21);
            this.tb_HB_CONTACT.TabIndex = 20;
            this.tb_HB_CONTACT.Text = "备战双11";
            // 
            // tb_JMP_URL
            // 
            this.tb_JMP_URL.Location = new System.Drawing.Point(120, 356);
            this.tb_JMP_URL.MaxLength = 0;
            this.tb_JMP_URL.Name = "tb_JMP_URL";
            this.tb_JMP_URL.Size = new System.Drawing.Size(114, 21);
            this.tb_JMP_URL.TabIndex = 21;
            this.tb_JMP_URL.Text = "http://shmmsns.qpic.cn/mmsns/jRoggJ2RF3DgpY5icgZxu6Azgic4t0AN2b5rFYh0aiaicjUYovWg" +
    "tMACq928G3MdngkVtCF9VCo1RqA/0";
            // 
            // sendForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1093, 553);
            this.Controls.Add(this.tb_JMP_URL);
            this.Controls.Add(this.tb_HB_CONTACT);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_SendALL);
            this.Controls.Add(this.btn_AutoAuth);
            this.Controls.Add(this.btn_SendBuf);
            this.Controls.Add(this.lable2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_Contents);
            this.Controls.Add(this.tb_toUsername);
            this.Controls.Add(this.lab_ShowMsg);
            this.Controls.Add(this.btn_GetLoginQrcode);
            this.Controls.Add(this.pB_ShowQrcode);
            this.Controls.Add(this.groupBox1);
            this.Name = "sendForm";
            this.Text = "WeChatProtocolSendConsole";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pB_ShowQrcode)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rb_ImgMsg;
        private System.Windows.Forms.RadioButton rb_LuckyMoneyMsg;
        private System.Windows.Forms.RadioButton rb_AppMsg;
        private System.Windows.Forms.RadioButton rb_VideMsg;
        private System.Windows.Forms.RadioButton rb_VoiceMsg;
        private System.Windows.Forms.RadioButton rb_TextMsg;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton rb_card;
        private System.Windows.Forms.RadioButton rb_sns;
        private System.Windows.Forms.RadioButton rb_delContact;
        private System.Windows.Forms.RadioButton rb_loginbyphone;
        private System.Windows.Forms.RadioButton rb_GetContact;
        private System.Windows.Forms.RadioButton rb_getkey;
        private System.Windows.Forms.RadioButton rb_addroomuser;
        private System.Windows.Forms.RadioButton rb_SearchContact;
        private System.Windows.Forms.RadioButton rb_delAllFriends;
        private System.Windows.Forms.RadioButton rb_QuitChatRoom;
        private System.Windows.Forms.RadioButton rb_video;
        private System.Windows.Forms.RadioButton rb_cndvideo;
        private System.Windows.Forms.RadioButton rb_SnsDetail;
        private System.Windows.Forms.RadioButton rb_delsns;
        private System.Windows.Forms.RadioButton rb_delComment;
        private System.Windows.Forms.RadioButton rb_like;
        private System.Windows.Forms.RadioButton rb_open;
        private System.Windows.Forms.RadioButton rb_VerifyPayPassword;
        private System.Windows.Forms.RadioButton rb_QueryRed;
        private System.Windows.Forms.PictureBox pB_ShowQrcode;
        private System.Windows.Forms.Button btn_GetLoginQrcode;
        private System.Windows.Forms.Label lab_ShowMsg;
        private System.Windows.Forms.TextBox tb_Contents;
        private System.Windows.Forms.TextBox tb_toUsername;
        private System.Windows.Forms.Label lable2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_SendBuf;
        private System.Windows.Forms.Button btn_AutoAuth;
        private System.Windows.Forms.Button btn_SendALL;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_HB_CONTACT;
        private System.Windows.Forms.TextBox tb_JMP_URL;
    }
}