namespace MicroMsg.Common.Event
{
    using System;
    

    public delegate void DispatcherEventDelegate(EventObject evtObject);
}

