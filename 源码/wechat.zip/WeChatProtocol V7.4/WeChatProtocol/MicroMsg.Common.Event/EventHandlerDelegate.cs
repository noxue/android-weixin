namespace MicroMsg.Common.Event
{
    using System;
    

    public delegate void EventHandlerDelegate(EventWatcher watcher, BaseEventArgs evtArgs);
}

