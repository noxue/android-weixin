namespace MicroMsg.Plugin.WCPay.Scene
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void NetSceneRedEnvelopesCallback(int retCode, string retMsg, object tag);
}

