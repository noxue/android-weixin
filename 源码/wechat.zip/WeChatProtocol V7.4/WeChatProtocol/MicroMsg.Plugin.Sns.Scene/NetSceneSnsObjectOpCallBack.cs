namespace MicroMsg.Plugin.Sns.Scene
{
    using System;
    using System.Collections.Generic;
    

    public delegate void NetSceneSnsObjectOpCallBack(IList<int> rspResultList);
}

