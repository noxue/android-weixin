namespace MicroMsg.Plugin.Sns.Scene
{
    using micromsg;
    public delegate void SnsUserPageCallBack(int ret_code, SnsUserPageResponse response);
}

