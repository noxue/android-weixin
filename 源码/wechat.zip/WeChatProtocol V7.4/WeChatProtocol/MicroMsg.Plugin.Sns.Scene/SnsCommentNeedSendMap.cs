namespace MicroMsg.Plugin.Sns.Scene
{
    using MicroMsg.Storage;
    using System;
    using System.Collections.Generic;

  
    public class SnsCommentNeedSendMap
    {
        public Dictionary<string, SnsCommentNeedSend> map = new Dictionary<string, SnsCommentNeedSend>();
    }
}

