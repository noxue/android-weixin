namespace MicroMsg.Plugin.Sns.Scene
{
    using System;

    public class CommentArg
    {
        public int commentID;
        public string strNickName;
        public string strUserName;
    }
}

