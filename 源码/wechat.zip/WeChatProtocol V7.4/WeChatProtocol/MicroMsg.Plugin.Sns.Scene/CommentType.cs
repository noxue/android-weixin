namespace MicroMsg.Manager
{
    using System;

    public enum CommentType : uint
    {
        MMSNS_COMMENT_LIKE = 1,
        MMSNS_COMMENT_MESSAGE = 3,
        MMSNS_COMMENT_STRANGER_LIKE = 5,
        MMSNS_COMMENT_TEXT = 2,
        MMSNS_COMMENT_WITH = 4
    }
}

