namespace MicroMsg.Plugin.Sns.Scene
{
    using System;

    public class SnsCommentServiceCenter
    {
        public static SnsCommentService snsCommentService = new SnsCommentService();
        private const string TAG = "SnsCommentServiceCenter";
    }
}

