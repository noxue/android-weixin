﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MicroMsg.Manager
{
    public class SyncData
    {
     
        public byte[] requestBuf;
       
        public byte[] responseBuf;
       
        public byte[] syncKey;

       // public SyncData();
    }
}
