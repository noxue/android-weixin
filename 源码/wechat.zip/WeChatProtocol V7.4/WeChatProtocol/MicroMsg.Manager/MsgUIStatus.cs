namespace MicroMsg.Manager
{
    using System;

    public enum MsgUIStatus
    {
        Processing,
        Fail,
        Success,
        Ready
    }
}

