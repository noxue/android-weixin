namespace MicroMsg.Manager
{
    using System;
    using System.Collections.Generic;

    public class MMReaderInfo
    {
        public int count;
        public List<MMReaderItem> items;
        public string name;
        public MMReaderTopNew topnew;
        public int type;
    }
}

