namespace MicroMsg.Manager
{
    using System;

    public class MMReaderTopNew
    {
        public string cover;
        public string digest;
        public int height;
        public int width;
    }
}

