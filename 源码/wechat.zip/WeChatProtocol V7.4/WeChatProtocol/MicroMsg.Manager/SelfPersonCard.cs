namespace MicroMsg.Manager
{
    using System;

    public class SelfPersonCard
    {
        public uint nPersonalCard;
        public int nSex;
        public string strCity;
        public string strCountry;
        public string strProvince;
        public string strSignature;
    }
}

