namespace MicroMsg.Manager
{
    using System;

    public class KVStat
    {
        public enKVStatKey key;
        public string value;
    }
}

