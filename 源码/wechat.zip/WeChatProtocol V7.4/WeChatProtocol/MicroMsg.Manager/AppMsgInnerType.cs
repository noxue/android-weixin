namespace MicroMsg.Manager
{
    using System;

    public enum AppMsgInnerType
    {
        MM_APP_EMOJI = 8,
        MM_APP_FILE = 6,
        MM_APP_IMG = 2,
        MM_APP_MUSIC = 3,
        MM_APP_OPEN = 7,
        MM_APP_TEXT = 1,
        MM_APP_UNKNOW = 9,
        MM_APP_URL = 5,
        MM_APP_VIDEO = 4
    }
}

