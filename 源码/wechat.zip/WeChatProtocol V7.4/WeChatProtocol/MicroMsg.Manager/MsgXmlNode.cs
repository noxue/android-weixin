namespace MicroMsg.Manager
{
    using System;

    public class MsgXmlNode
    {
        public string Name;
        public string parentName;
        public string Value;
    }
}

