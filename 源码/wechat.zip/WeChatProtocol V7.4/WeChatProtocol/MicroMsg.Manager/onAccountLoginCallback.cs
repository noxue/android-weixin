namespace MicroMsg.Manager
{
    using System;
    

    public delegate void onAccountLoginCallback();
}

