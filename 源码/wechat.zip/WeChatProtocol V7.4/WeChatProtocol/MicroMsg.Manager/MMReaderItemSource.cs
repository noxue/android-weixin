namespace MicroMsg.Manager
{
    using System;

    public class MMReaderItemSource
    {
        public string icon;
        public string name;
    }
}

