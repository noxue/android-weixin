namespace MicroMsg.Manager
{
    using System;
    
    using System.Runtime.Serialization;

    
    public class AppMusicInfo
    {
        
        public string netType { get; set; }

        
        public string song_Album { get; set; }

        
        public string song_ID { get; set; }

        
        public string song_Name { get; set; }

        
        public string song_Singer { get; set; }

        
        public string song_Type { get; set; }

        
        public string song_WapDownLoadURL { get; set; }

        
        public string song_WapLiveURL { get; set; }

        
        public string song_WifiURL { get; set; }
    }
}

