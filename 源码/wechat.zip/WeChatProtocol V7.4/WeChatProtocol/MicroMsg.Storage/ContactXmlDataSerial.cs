namespace MicroMsg.Storage
{
    using System;
    using System.Runtime.Serialization;


    public class ContactXmlDataSerial
    {

        public ContactXmlData data;
    }
}

