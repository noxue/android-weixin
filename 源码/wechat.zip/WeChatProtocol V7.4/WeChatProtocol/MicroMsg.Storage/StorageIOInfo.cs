namespace MicroMsg.Storage
{
    using System;

    public class StorageIOInfo
    {
        public uint lastInitClientVersion;
    }
}

