namespace MicroMsg.Storage
{
    using System;
    using System.Runtime.Serialization;


    public class MsgXmlData
    {
        
        public bool isGifRead;
        
        public bool isVoiceRead;
        
        public string strImagePath;
        
        public string strThumbnail;
        public string msgSource;
    }
}

