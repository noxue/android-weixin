namespace MicroMsg.Storage
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.Serialization;


    public class SnsGroupList
    {
    
        public List<ulong> list = new List<ulong>();

        public int nCount;
    }
}

