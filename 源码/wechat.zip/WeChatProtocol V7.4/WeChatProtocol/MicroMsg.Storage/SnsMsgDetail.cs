namespace MicroMsg.Storage
{
    using System;
    using System.Runtime.Serialization;


    public class SnsMsgDetail
    {
       
        public int nCommentId;
       
        public uint nCreateTime;
       
        public int nReplyCommentId;
       
        public uint nSource;
       
        public uint nType;
       
        public string strContent;
       
        public string strFromNickname;
       
        public string strFromUsername;
       
        public string strToNickname;
       
        public string strToUsername;
    }
}

