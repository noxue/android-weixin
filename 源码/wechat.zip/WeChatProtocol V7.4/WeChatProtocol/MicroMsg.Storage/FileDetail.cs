namespace MicroMsg.Storage
{
    using System;

    public class FileDetail
    {
        public long idleMinutes;
        public string strFileName;
    }
}

