namespace MicroMsg.Storage
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.Serialization;


    public class SnsCommentList
    {

        public List<SnsComment> list = new List<SnsComment>();
    }
}

