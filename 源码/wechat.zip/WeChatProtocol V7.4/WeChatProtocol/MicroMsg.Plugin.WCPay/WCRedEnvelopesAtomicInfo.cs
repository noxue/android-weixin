namespace MicroMsg.Plugin.WCPay
{
    using System;

    public class WCRedEnvelopesAtomicInfo
    {
        public bool m_bEnable;
        public string m_nsAtomicTitle;
        public string m_nsAtomicUrl;
        public long m_nsSessionKey;
    }
}

