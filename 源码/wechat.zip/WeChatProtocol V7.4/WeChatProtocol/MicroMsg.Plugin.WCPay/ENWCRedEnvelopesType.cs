namespace MicroMsg.Plugin.WCPay
{
    using System;

    public enum ENWCRedEnvelopesType
    {
        ENWCRedEnvelopesTypeDefaultNormalType,
        ENWCRedEnvelopesTypeDefaultGroupType
    }
}

