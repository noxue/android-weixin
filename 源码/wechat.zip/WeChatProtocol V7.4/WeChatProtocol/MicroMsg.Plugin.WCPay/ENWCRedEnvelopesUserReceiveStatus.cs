namespace MicroMsg.Plugin.WCPay
{
    using System;

    public enum ENWCRedEnvelopesUserReceiveStatus
    {
        ENWCRedEnvelopesUserReceiveCanReceiveStatus,
        ENWCRedEnvelopesUserReceiveNotAllowStatus,
        ENWCRedEnvelopesUserReceiveHasReceivedStatus
    }
}

