namespace MicroMsg.Plugin.WCPay
{
    using System;

    public enum ENWCRedEnvelopesKind
    {
        ENWCRedEnvelopesTypeDefaultNormalKind = 1,
        ENWCRedEnvelopesTypeEnterpriceseKind = 2,
        ENWCRedEnvelopesTypeSpringKind = 3
    }
}

