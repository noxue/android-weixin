namespace MicroMsg.Scene.Voice
{
    using System;

    public enum DownloadPackNum
    {
        NETWORK_2G_NUM = 1,
        NETWORK_3G_NUM = 2,
        NETWORK_WIFI_NUM = 20
    }
}

