namespace MicroMsg.Scene.Voice
{
    using System;
    

    public delegate void onSceneFinishedDelegate(UploadVoiceContext context);
}

