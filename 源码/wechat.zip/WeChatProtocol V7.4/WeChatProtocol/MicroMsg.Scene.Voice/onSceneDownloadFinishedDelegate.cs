namespace MicroMsg.Scene.Voice
{
    using System;
    

    public delegate void onSceneDownloadFinishedDelegate(DownloadVoiceContext context);
}

