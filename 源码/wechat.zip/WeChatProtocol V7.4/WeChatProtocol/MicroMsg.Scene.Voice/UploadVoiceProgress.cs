namespace MicroMsg.Scene.Voice
{
    using System;

    public class UploadVoiceProgress
    {
        public string clientMsgId;
        public int voiceTimeLength;
    }
}

