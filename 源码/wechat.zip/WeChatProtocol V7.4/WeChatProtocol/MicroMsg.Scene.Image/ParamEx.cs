namespace MicroMsg.Scene.Image
{
    using System;

    public class ParamEx
    {
        public bool isNeedScale = true;
        public string thumbPath;
    }
}

