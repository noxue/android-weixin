namespace MicroMsg.Scene.Video
{
    using System;

    public enum enVideoFuncFlag
    {
        MM_VIDEO_FUNCFLAG_EXPORT = 2,
        MM_VIDEO_FUNCFLAG_SELF = 1,
        MM_VIDEO_FUNCFLAG_SHORT = 3
    }
}

