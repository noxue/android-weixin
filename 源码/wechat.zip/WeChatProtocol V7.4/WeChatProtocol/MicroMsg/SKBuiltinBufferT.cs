namespace micromsg
{
    using Google.ProtocolBuffers;
    using System;
    using System.CodeDom.Compiler;
    using System.Diagnostics;
    

    
    public static class SKBuiltinBufferT
    {
        internal static readonly object Descriptor = null;

        public static void RegisterAllExtensions(ExtensionRegistry registry)
        {
        }
    }
}

