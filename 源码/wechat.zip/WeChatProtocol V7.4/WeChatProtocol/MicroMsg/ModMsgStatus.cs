namespace micromsg
{
    using Google.ProtocolBuffers;
    
    using System;
    using System.CodeDom.Compiler;
    using System.Diagnostics;
    using System.IO;
    

    //
    public sealed class ModMsgStatus : GeneratedMessageLite<ModMsgStatus, ModMsgStatus.Builder>
    {
        private static readonly string[] _modMsgStatusFieldNames = new string[] { "FromUserName", "MsgId", "Status", "ToUserName" };
        private static readonly uint[] _modMsgStatusFieldTags = new uint[] { 0x12, 8, 0x20, 0x1a };
        private static readonly ModMsgStatus defaultInstance = new ModMsgStatus().MakeReadOnly();
        private SKBuiltinString_t fromUserName_;
        public const int FromUserNameFieldNumber = 2;
        private bool hasFromUserName;
        private bool hasMsgId;
        private bool hasStatus;
        private bool hasToUserName;
        private int memoizedSerializedSize = -1;
        private int msgId_;
        public const int MsgIdFieldNumber = 1;
        private uint status_;
        public const int StatusFieldNumber = 4;
        private SKBuiltinString_t toUserName_;
        public const int ToUserNameFieldNumber = 3;

        static ModMsgStatus()
        {
           // object.ReferenceEquals(ModMsgStatus.Descriptor, null);
        }

        private ModMsgStatus()
        {
        }

        public static Builder CreateBuilder()
        {
            return new Builder();
        }

        public static Builder CreateBuilder(ModMsgStatus prototype)
        {
            return new Builder(prototype);
        }

        public override Builder CreateBuilderForType()
        {
            return new Builder();
        }

        public override bool Equals(object obj)
        {
            ModMsgStatus status = obj as ModMsgStatus;
            if (status == null)
            {
                return false;
            }
            if ((this.hasMsgId != status.hasMsgId) || (this.hasMsgId && !this.msgId_.Equals(status.msgId_)))
            {
                return false;
            }
            if ((this.hasFromUserName != status.hasFromUserName) || (this.hasFromUserName && !this.fromUserName_.Equals(status.fromUserName_)))
            {
                return false;
            }
            if ((this.hasToUserName != status.hasToUserName) || (this.hasToUserName && !this.toUserName_.Equals(status.toUserName_)))
            {
                return false;
            }
            return ((this.hasStatus == status.hasStatus) && (!this.hasStatus || this.status_.Equals(status.status_)));
        }

        public override int GetHashCode()
        {
            int hashCode = base.GetType().GetHashCode();
            if (this.hasMsgId)
            {
                hashCode ^= this.msgId_.GetHashCode();
            }
            if (this.hasFromUserName)
            {
                hashCode ^= this.fromUserName_.GetHashCode();
            }
            if (this.hasToUserName)
            {
                hashCode ^= this.toUserName_.GetHashCode();
            }
            if (this.hasStatus)
            {
                hashCode ^= this.status_.GetHashCode();
            }
            return hashCode;
        }

        private ModMsgStatus MakeReadOnly()
        {
            return this;
        }

        public static ModMsgStatus ParseFrom(byte[] data)
        {
            return CreateBuilder().MergeFrom(data).BuildParsed();
        }

        public override void PrintTo(TextWriter writer)
        {
            GeneratedMessageLite<ModMsgStatus, Builder>.PrintField("MsgId", this.hasMsgId, this.msgId_, writer);
            GeneratedMessageLite<ModMsgStatus, Builder>.PrintField("FromUserName", this.hasFromUserName, this.fromUserName_, writer);
            GeneratedMessageLite<ModMsgStatus, Builder>.PrintField("ToUserName", this.hasToUserName, this.toUserName_, writer);
            GeneratedMessageLite<ModMsgStatus, Builder>.PrintField("Status", this.hasStatus, this.status_, writer);
        }

        public override Builder ToBuilder()
        {
            return CreateBuilder(this);
        }

        public override void WriteTo(ICodedOutputStream output)
        {
            int serializedSize = this.SerializedSize;
            string[] strArray = _modMsgStatusFieldNames;
            if (this.hasMsgId)
            {
                output.WriteInt32(1, strArray[1], this.MsgId);
            }
            if (this.hasFromUserName)
            {
                output.WriteMessage(2, strArray[0], this.FromUserName);
            }
            if (this.hasToUserName)
            {
                output.WriteMessage(3, strArray[3], this.ToUserName);
            }
            if (this.hasStatus)
            {
                output.WriteUInt32(4, strArray[2], this.Status);
            }
        }

        public static ModMsgStatus DefaultInstance
        {
            get
            {
                return defaultInstance;
            }
        }

        public override ModMsgStatus DefaultInstanceForType
        {
            get
            {
                return DefaultInstance;
            }
        }

        public SKBuiltinString_t FromUserName
        {
            get
            {
                return (this.fromUserName_ ?? SKBuiltinString_t.DefaultInstance);
            }
        }

        public override bool IsInitialized
        {
            get
            {
                if (!this.hasMsgId)
                {
                    return false;
                }
                if (!this.hasFromUserName)
                {
                    return false;
                }
                if (!this.hasToUserName)
                {
                    return false;
                }
                if (!this.hasStatus)
                {
                    return false;
                }
                return true;
            }
        }

        public int MsgId
        {
            get
            {
                return this.msgId_;
            }
        }

        public override int SerializedSize
        {
            get
            {
                int memoizedSerializedSize = this.memoizedSerializedSize;
                if (memoizedSerializedSize == -1)
                {
                    memoizedSerializedSize = 0;
                    if (this.hasMsgId)
                    {
                        memoizedSerializedSize += CodedOutputStream.ComputeInt32Size(1, this.MsgId);
                    }
                    if (this.hasFromUserName)
                    {
                        memoizedSerializedSize += CodedOutputStream.ComputeMessageSize(2, this.FromUserName);
                    }
                    if (this.hasToUserName)
                    {
                        memoizedSerializedSize += CodedOutputStream.ComputeMessageSize(3, this.ToUserName);
                    }
                    if (this.hasStatus)
                    {
                        memoizedSerializedSize += CodedOutputStream.ComputeUInt32Size(4, this.Status);
                    }
                    this.memoizedSerializedSize = memoizedSerializedSize;
                }
                return memoizedSerializedSize;
            }
        }

        public uint Status
        {
            get
            {
                return this.status_;
            }
        }

        protected override ModMsgStatus ThisMessage
        {
            get
            {
                return this;
            }
        }

        public SKBuiltinString_t ToUserName
        {
            get
            {
                return (this.toUserName_ ?? SKBuiltinString_t.DefaultInstance);
            }
        }

        
        public sealed class Builder : GeneratedBuilderLite<ModMsgStatus, ModMsgStatus.Builder>
        {
            private ModMsgStatus result;
            private bool resultIsReadOnly;

            public Builder()
            {
                this.result = ModMsgStatus.DefaultInstance;
                this.resultIsReadOnly = true;
            }

            internal Builder(ModMsgStatus cloneFrom)
            {
                this.result = cloneFrom;
                this.resultIsReadOnly = true;
            }

            public override ModMsgStatus BuildPartial()
            {
                if (this.resultIsReadOnly)
                {
                    return this.result;
                }
                this.resultIsReadOnly = true;
                return this.result.MakeReadOnly();
            }

            public override ModMsgStatus.Builder Clear()
            {
                this.result = ModMsgStatus.DefaultInstance;
                this.resultIsReadOnly = true;
                return this;
            }

            public ModMsgStatus.Builder ClearFromUserName()
            {
                this.PrepareBuilder();
                this.result.hasFromUserName = false;
                this.result.fromUserName_ = null;
                return this;
            }

            public ModMsgStatus.Builder ClearMsgId()
            {
                this.PrepareBuilder();
                this.result.hasMsgId = false;
                this.result.msgId_ = 0;
                return this;
            }

            public ModMsgStatus.Builder ClearStatus()
            {
                this.PrepareBuilder();
                this.result.hasStatus = false;
                this.result.status_ = 0;
                return this;
            }

            public ModMsgStatus.Builder ClearToUserName()
            {
                this.PrepareBuilder();
                this.result.hasToUserName = false;
                this.result.toUserName_ = null;
                return this;
            }

            public override ModMsgStatus.Builder Clone()
            {
                if (this.resultIsReadOnly)
                {
                    return new ModMsgStatus.Builder(this.result);
                }
                return new ModMsgStatus.Builder().MergeFrom(this.result);
            }

            public override ModMsgStatus.Builder MergeFrom(ICodedInputStream input)
            {
                return this.MergeFrom(input, ExtensionRegistry.Empty);
            }

            public override ModMsgStatus.Builder MergeFrom(IMessageLite other)
            {
                if (other is ModMsgStatus)
                {
                    return this.MergeFrom((ModMsgStatus) other);
                }
                base.MergeFrom(other);
                return this;
            }

            public override ModMsgStatus.Builder MergeFrom(ModMsgStatus other)
            {
                return this;
            }

            public override ModMsgStatus.Builder MergeFrom(ICodedInputStream input, ExtensionRegistry extensionRegistry)
            {
                uint num;
                string str;
                this.PrepareBuilder();
                while (input.ReadTag(out num, out str))
                {
                    if ((num == 0) && (str != null))
                    {
                        int index = Array.BinarySearch<string>(ModMsgStatus._modMsgStatusFieldNames, str, StringComparer.Ordinal);
                        if (index >= 0)
                        {
                            num = ModMsgStatus._modMsgStatusFieldTags[index];
                        }
                        else
                        {
                            this.ParseUnknownField(input, extensionRegistry, num, str);
                            continue;
                        }
                    }
                    switch (num)
                    {
                        case 0:
                            throw InvalidProtocolBufferException.InvalidTag();

                        case 8:
                        {
                            this.result.hasMsgId = input.ReadInt32(ref this.result.msgId_);
                            continue;
                        }
                        case 0x12:
                        {
                            SKBuiltinString_t.Builder builder = SKBuiltinString_t.CreateBuilder();
                            if (this.result.hasFromUserName)
                            {
                                builder.MergeFrom(this.FromUserName);
                            }
                            input.ReadMessage(builder, extensionRegistry);
                            this.FromUserName = builder.BuildPartial();
                            continue;
                        }
                        case 0x1a:
                        {
                            SKBuiltinString_t.Builder builder2 = SKBuiltinString_t.CreateBuilder();
                            if (this.result.hasToUserName)
                            {
                                builder2.MergeFrom(this.ToUserName);
                            }
                            input.ReadMessage(builder2, extensionRegistry);
                            this.ToUserName = builder2.BuildPartial();
                            continue;
                        }
                        case 0x20:
                            break;

                        default:
                        {
                            if (WireFormat.IsEndGroupTag(num))
                            {
                                return this;
                            }
                            this.ParseUnknownField(input, extensionRegistry, num, str);
                            continue;
                        }
                    }
                    this.result.hasStatus = input.ReadUInt32(ref this.result.status_);
                }
                return this;
            }

            public ModMsgStatus.Builder MergeFromUserName(SKBuiltinString_t value)
            {
                ThrowHelper.ThrowIfNull(value, "value");
                this.PrepareBuilder();
                if (this.result.hasFromUserName && (this.result.fromUserName_ != SKBuiltinString_t.DefaultInstance))
                {
                    this.result.fromUserName_ = SKBuiltinString_t.CreateBuilder(this.result.fromUserName_).MergeFrom(value).BuildPartial();
                }
                else
                {
                    this.result.fromUserName_ = value;
                }
                this.result.hasFromUserName = true;
                return this;
            }

            public ModMsgStatus.Builder MergeToUserName(SKBuiltinString_t value)
            {
                ThrowHelper.ThrowIfNull(value, "value");
                this.PrepareBuilder();
                if (this.result.hasToUserName && (this.result.toUserName_ != SKBuiltinString_t.DefaultInstance))
                {
                    this.result.toUserName_ = SKBuiltinString_t.CreateBuilder(this.result.toUserName_).MergeFrom(value).BuildPartial();
                }
                else
                {
                    this.result.toUserName_ = value;
                }
                this.result.hasToUserName = true;
                return this;
            }

            private ModMsgStatus PrepareBuilder()
            {
                if (this.resultIsReadOnly)
                {
                    ModMsgStatus result = this.result;
                    this.result = new ModMsgStatus();
                    this.resultIsReadOnly = false;
                    this.MergeFrom(result);
                }
                return this.result;
            }

            public ModMsgStatus.Builder SetFromUserName(SKBuiltinString_t value)
            {
                ThrowHelper.ThrowIfNull(value, "value");
                this.PrepareBuilder();
                this.result.hasFromUserName = true;
                this.result.fromUserName_ = value;
                return this;
            }

            public ModMsgStatus.Builder SetFromUserName(SKBuiltinString_t.Builder builderForValue)
            {
                ThrowHelper.ThrowIfNull(builderForValue, "builderForValue");
                this.PrepareBuilder();
                this.result.hasFromUserName = true;
                this.result.fromUserName_ = builderForValue.Build();
                return this;
            }

            public ModMsgStatus.Builder SetMsgId(int value)
            {
                this.PrepareBuilder();
                this.result.hasMsgId = true;
                this.result.msgId_ = value;
                return this;
            }

            public ModMsgStatus.Builder SetStatus(uint value)
            {
                this.PrepareBuilder();
                this.result.hasStatus = true;
                this.result.status_ = value;
                return this;
            }

            public ModMsgStatus.Builder SetToUserName(SKBuiltinString_t value)
            {
                ThrowHelper.ThrowIfNull(value, "value");
                this.PrepareBuilder();
                this.result.hasToUserName = true;
                this.result.toUserName_ = value;
                return this;
            }

            public ModMsgStatus.Builder SetToUserName(SKBuiltinString_t.Builder builderForValue)
            {
                ThrowHelper.ThrowIfNull(builderForValue, "builderForValue");
                this.PrepareBuilder();
                this.result.hasToUserName = true;
                this.result.toUserName_ = builderForValue.Build();
                return this;
            }

            public override ModMsgStatus DefaultInstanceForType
            {
                get
                {
                    return ModMsgStatus.DefaultInstance;
                }
            }

            public SKBuiltinString_t FromUserName
            {
                get
                {
                    return this.result.FromUserName;
                }
                set
                {
                    this.SetFromUserName(value);
                }
            }

            public override bool IsInitialized
            {
                get
                {
                    return this.result.IsInitialized;
                }
            }

            protected override ModMsgStatus MessageBeingBuilt
            {
                get
                {
                    return this.PrepareBuilder();
                }
            }

            public int MsgId
            {
                get
                {
                    return this.result.MsgId;
                }
                set
                {
                    this.SetMsgId(value);
                }
            }

            public uint Status
            {
                get
                {
                    return this.result.Status;
                }
                set
                {
                    this.SetStatus(value);
                }
            }

            protected override ModMsgStatus.Builder ThisBuilder
            {
                get
                {
                    return this;
                }
            }

            public SKBuiltinString_t ToUserName
            {
                get
                {
                    return this.result.ToUserName;
                }
                set
                {
                    this.SetToUserName(value);
                }
            }
        }
    }
}

