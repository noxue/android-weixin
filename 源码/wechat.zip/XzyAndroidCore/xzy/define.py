__CLIENT_VERSION__                          = 637927472
GUID                                        = "Aff0aef642a31fc2"
__GUID__                                    = GUID[:15]
__CLIENT_SEQID__                            = GUID + "_1522827110765"
__CLIENT_SEQID_SIGN__                       = "e89b158e4bcf988ebd09eb83f5378e87"
__IMEI__                                    = "865166024671219"
__ANDROID_ID__                              = "d3151233cfbb4fd4"
__ANDROID_VER__                             = "android-22"
__MANUFACTURER__                            = "Xuzeyu"
__MODELNAME__                               = "-core"
__MOBILE_WIFI_MAC_ADDRESS__                 = "01:61:19:58:78:d3"
__AP_BSSID__                                = "41:27:91:12:3e:14"
__LANGUAGE__                                = "zh_CN"
__SOFTINFO__                                = "<softtype><lctmoc>0</lctmoc><level>1</level><k1>ARMv7 processor rev 1 (v7l) </k1><k2></k2><k3>5.1.1</k3><k4>{}</k4><k5>460007337766541</k5><k6>89860012221746527381</k6><k7>{}</k7><k8>unknown</k8><k9>{}</k9><k10>2</k10><k11>placeholder</k11><k12>0001</k12><k13>0000000000000001</k13><k14>{}</k14><k15></k15><k16>neon vfp swp half thumb fastmult edsp vfpv3 idiva idivt</k16><k18>{}</k18><k21>\"wireless\"</k21><k22></k22><k24>{}</k24><k26>0</k26><k30>\"wireless\"</k30><k33>com.tencent.mm</k33><k34>Android-x86/android_x86/x86:5.1.1/LMY48Z/denglibo08021647:userdebug/test-keys</k34><k35>vivo v3</k35><k36>unknown</k36><k37>{}</k37><k38>x86</k38><k39>android_x86</k39><k40>{}</k40><k41>1</k41><k42>{}</k42><k43>null</k43><k44>0</k44><k45></k45><k46></k46><k47>wifi</k47><k48>{}</k48><k49>/data/data/com.tencent.mm/</k49><k52>0</k52><k53>0</k53><k57>1080</k57><k58></k58><k59>0</k59></softtype>"
__DEVICEINFO__                              = "<deviceinfo><MANUFACTURER name=\"{}\"><MODEL name=\"{}\"><VERSION_RELEASE name=\"5.1.1\"><VERSION_INCREMENTAL name=\"eng.denglibo.20171224.164708\"><DISPLAY name=\"android_x86-userdebug 5.1.1 LMY48Z eng.denglibo.20171224.164708 test-keys\"></DISPLAY></VERSION_INCREMENTAL></VERSION_RELEASE></MODEL></MANUFACTURER></deviceinfo>"

__LOGIN_RSA_VER__						    = 158
__LOGIN_RSA_VER158_KEY_E__				    = 65537
__LOGIN_RSA_VER158_KEY_N__                  = "E161DA03D0B6AAD21F9A4FB27C32A3208AF25A707BB0E8ECE79506FBBAF97519D9794B7E1B44D2C6F2588495C4E040303B4C915F172DD558A49552762CB28AB309C08152A8C55A4DFC6EA80D1F4D860190A8EE251DF8DECB9B083674D56CD956FF652C3C724B9F02BE5C7CBC63FC0124AA260D889A73E91292B6A02121D25AAA7C1A87752575C181FFB25A6282725B0C38A2AD57676E0884FE20CF56256E14529BC7E82CD1F4A1155984512BD273D68F769AF46E1B0E3053816D39EB1F0588384F2F4B286E5CFAFB4D0435BDF7D3AA8D3E0C45716EAD190FDC66884B275BA08D8ED94B1F84E7729C25BD014E7FA3A23123E10D3A93B4154452DDB9EE5F8DAB67"

#发送名片时,username必须为有效wxid,否则发送失败
CONTACT_CARD                                = '<msg username="{}" nickname="{}" alias="" fullpy="" shortpy="" imagestatus="3" scene="17" province="" city="" sign="" percard="0" sex="0" certflag="0" certinfo="" certinfoext="" brandIconUrl="" brandHomeUrl="" brandSubscriptConfigUrl="" brandFlags="" regionCode=""/>'

#分享链接
SHARE_LINK                                  = '<appmsg appid="" sdkver="0"><title>{}</title><des>{}</des><username></username><action>view</action><type>5</type><showtype>0</showtype><content></content><url>{}</url><lowurl></lowurl><dataurl></dataurl><lowdataurl></lowdataurl><contentattr>0</contentattr><streamvideo><streamvideourl></streamvideourl><streamvideototaltime>0</streamvideototaltime><streamvideotitle></streamvideotitle><streamvideowording></streamvideowording><streamvideoweburl></streamvideoweburl><streamvideothumburl></streamvideothumburl><streamvideoaduxinfo></streamvideoaduxinfo><streamvideopublishid></streamvideopublishid></streamvideo><canvasPageItem><canvasPageXml><![CDATA[]]></canvasPageXml></canvasPageItem><appattach><totallen>0</totallen><attachid></attachid><cdnattachurl></cdnattachurl><emoticonmd5></emoticonmd5><aeskey></aeskey><fileext></fileext><islargefilemsg>0</islargefilemsg></appattach><extinfo></extinfo><androidsource>3</androidsource><thumburl>{}</thumburl><mediatagname></mediatagname><messageaction><![CDATA[]]></messageaction><messageext><![CDATA[]]></messageext><emoticongift><packageflag>0</packageflag><packageid></packageid></emoticongift><emoticonshared><packageflag>0</packageflag><packageid></packageid></emoticonshared><designershared><designeruin>0</designeruin><designername>null</designername><designerrediretcturl>null</designerrediretcturl></designershared><emotionpageshared><tid>0</tid><title>null</title><desc>null</desc><iconUrl>null</iconUrl><secondUrl></secondUrl><pageType>0</pageType></emotionpageshared><webviewshared><shareUrlOriginal></shareUrlOriginal><shareUrlOpen></shareUrlOpen><jsAppId></jsAppId><publisherId></publisherId></webviewshared><template_id></template_id><md5></md5><weappinfo><username></username><appid></appid><appservicetype>0</appservicetype></weappinfo><statextstr></statextstr><websearch></websearch></appmsg>'

#好友添加来源
WAY                                         = {0:'未知来源',1:'QQ',3:'微信号',10:'手机通讯录',13:'手机通讯录',14:'群聊',15:'手机号',17:'名片分享',18:'附近的人',28:'摇一摇',30:'扫一扫'}

#系统服务(获取好友列表时过滤掉这些wxid)
MM_DEFAULT_WXID                             = ("weixin","qqmail", "fmessage", "tmessage", "qmessage", "qqsync", "floatbottle", "lbsapp", "shakeapp", "medianote", "qqfriend", "newsapp", "blogapp", "facebookapp", "masssendapp", "feedsapp", "voipapp", "cardpackage", "voicevoipapp", "voiceinputapp", "officialaccounts", "linkedinplugin", "notifymessage", "appbrandcustomerservicemsg","pc_share","notification_messages","helper_entry","filehelper")