﻿namespace Wechat
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btn_GetQrcode = new System.Windows.Forms.Button();
            this.pB_Qrcode = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rtb_Msg = new System.Windows.Forms.RichTextBox();
            this.tb_Content = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_ToUsername = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.btn_DelContactLabel = new System.Windows.Forms.Button();
            this.btn_ModifyLabelList = new System.Windows.Forms.Button();
            this.btn_AddLabel = new System.Windows.Forms.Button();
            this.btn_GetLabelList = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btn_shakeGet = new System.Windows.Forms.Button();
            this.btn_lbsfind = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.btn_SendCDnimg = new System.Windows.Forms.Button();
            this.btn_downloadMsgimg = new System.Windows.Forms.Button();
            this.btn_SendAppMsg = new System.Windows.Forms.Button();
            this.btn_SendCardMsg = new System.Windows.Forms.Button();
            this.btn_SendMsg = new System.Windows.Forms.Button();
            this.btn_SendVoice = new System.Windows.Forms.Button();
            this.btn_SendMsgimg = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btn_SnsUpload = new System.Windows.Forms.Button();
            this.btn_SnsSync = new System.Windows.Forms.Button();
            this.btn_SnsPost = new System.Windows.Forms.Button();
            this.btn_SnsObjectOp = new System.Windows.Forms.Button();
            this.btn_SnsTimeLine = new System.Windows.Forms.Button();
            this.btn_SnsUserPage = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.btn_BindEail = new System.Windows.Forms.Button();
            this.btn_GetContact = new System.Windows.Forms.Button();
            this.btn_SearchContact = new System.Windows.Forms.Button();
            this.btn_initcontact = new System.Windows.Forms.Button();
            this.btn_get = new System.Windows.Forms.Button();
            this.btn_GetA8Key = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.btn_UpMobile = new System.Windows.Forms.Button();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.btn_AddFavItem = new System.Windows.Forms.Button();
            this.btn_DelFavItem = new System.Windows.Forms.Button();
            this.btn_GetFavItem = new System.Windows.Forms.Button();
            this.btn_FavSync = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.btn_Add_Gh = new System.Windows.Forms.Button();
            this.btn_SayHello = new System.Windows.Forms.Button();
            this.btn_AcceptUser = new System.Windows.Forms.Button();
            this.btn_AddUser = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_SetChatRoomAnnouncement = new System.Windows.Forms.Button();
            this.btn_GetRoomDetail = new System.Windows.Forms.Button();
            this.btn_DelChatRoomUser = new System.Windows.Forms.Button();
            this.btn_AddChatRoomMember = new System.Windows.Forms.Button();
            this.btn_CreateChatRoom = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.btn_TenPay_TransferConfirm = new System.Windows.Forms.Button();
            this.btn_TransferReq = new System.Windows.Forms.Button();
            this.btn_GenPreTransferReq = new System.Windows.Forms.Button();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.btn_Fetchauthen = new System.Windows.Forms.Button();
            this.btn_GetBalance = new System.Windows.Forms.Button();
            this.btn_Genprefetch = new System.Windows.Forms.Button();
            this.btn_GetBlankID = new System.Windows.Forms.Button();
            this.btn_F2ffee = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.button8 = new System.Windows.Forms.Button();
            this.btn_Bindmolie_yzcode = new System.Windows.Forms.Button();
            this.btn_BindMobile_getcode = new System.Windows.Forms.Button();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.btn_setPwd = new System.Windows.Forms.Button();
            this.btn_verifyPwd = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.Btn_DataLogin = new System.Windows.Forms.Button();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.btn_ZC = new System.Windows.Forms.Button();
            this.btn_NewReg = new System.Windows.Forms.Button();
            this.btn_ChackSmsCode = new System.Windows.Forms.Button();
            this.btn_GetSms = new System.Windows.Forms.Button();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.btn_deviceLogins = new System.Windows.Forms.Button();
            this.btn_loginBySms = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btn_logoutweb = new System.Windows.Forms.Button();
            this.btn_GetLoginSmsCodes = new System.Windows.Forms.Button();
            this.btn_PushUrlLogin = new System.Windows.Forms.Button();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.btn_logout = new System.Windows.Forms.Button();
            this.btn_SyncCheck = new System.Windows.Forms.Button();
            this.btn_AutoAuth = new System.Windows.Forms.Button();
            this.btn_Sync = new System.Windows.Forms.Button();
            this.btn_NewInit = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_AtUserlist = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Qrcode)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_GetQrcode
            // 
            this.btn_GetQrcode.Location = new System.Drawing.Point(166, 17);
            this.btn_GetQrcode.Name = "btn_GetQrcode";
            this.btn_GetQrcode.Size = new System.Drawing.Size(112, 23);
            this.btn_GetQrcode.TabIndex = 32;
            this.btn_GetQrcode.Text = "获取二维码";
            this.btn_GetQrcode.UseVisualStyleBackColor = true;
            this.btn_GetQrcode.Click += new System.EventHandler(this.btn_GetQrcode_Click);
            // 
            // pB_Qrcode
            // 
            this.pB_Qrcode.Location = new System.Drawing.Point(12, 17);
            this.pB_Qrcode.Name = "pB_Qrcode";
            this.pB_Qrcode.Size = new System.Drawing.Size(138, 135);
            this.pB_Qrcode.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pB_Qrcode.TabIndex = 31;
            this.pB_Qrcode.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rtb_Msg);
            this.groupBox3.Location = new System.Drawing.Point(665, 10);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(283, 556);
            this.groupBox3.TabIndex = 30;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "MsgConsole";
            // 
            // rtb_Msg
            // 
            this.rtb_Msg.Location = new System.Drawing.Point(12, 20);
            this.rtb_Msg.Name = "rtb_Msg";
            this.rtb_Msg.Size = new System.Drawing.Size(265, 519);
            this.rtb_Msg.TabIndex = 5;
            this.rtb_Msg.Text = "";
            // 
            // tb_Content
            // 
            this.tb_Content.Location = new System.Drawing.Point(267, 55);
            this.tb_Content.Multiline = true;
            this.tb_Content.Name = "tb_Content";
            this.tb_Content.Size = new System.Drawing.Size(232, 36);
            this.tb_Content.TabIndex = 34;
            this.tb_Content.Text = resources.GetString("tb_Content.Text");
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(541, 53);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 36;
            this.button1.Text = "test";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(190, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 12);
            this.label3.TabIndex = 38;
            this.label3.Text = "ToUsername:";
            // 
            // tb_ToUsername
            // 
            this.tb_ToUsername.Location = new System.Drawing.Point(267, 110);
            this.tb_ToUsername.Name = "tb_ToUsername";
            this.tb_ToUsername.Size = new System.Drawing.Size(232, 21);
            this.tb_ToUsername.TabIndex = 37;
            this.tb_ToUsername.Text = "0094729345849";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(12, 166);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(647, 411);
            this.tabControl1.TabIndex = 40;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox7);
            this.tabPage1.Controls.Add(this.groupBox6);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(639, 385);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "信息操作";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.btn_DelContactLabel);
            this.groupBox7.Controls.Add(this.btn_ModifyLabelList);
            this.groupBox7.Controls.Add(this.btn_AddLabel);
            this.groupBox7.Controls.Add(this.btn_GetLabelList);
            this.groupBox7.Location = new System.Drawing.Point(313, 121);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(134, 142);
            this.groupBox7.TabIndex = 38;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "通讯录标签操作";
            // 
            // btn_DelContactLabel
            // 
            this.btn_DelContactLabel.Location = new System.Drawing.Point(15, 111);
            this.btn_DelContactLabel.Name = "btn_DelContactLabel";
            this.btn_DelContactLabel.Size = new System.Drawing.Size(110, 25);
            this.btn_DelContactLabel.TabIndex = 31;
            this.btn_DelContactLabel.Text = "删除标签列表";
            this.btn_DelContactLabel.UseVisualStyleBackColor = true;
            this.btn_DelContactLabel.Click += new System.EventHandler(this.btn_DelContactLabel_Click);
            // 
            // btn_ModifyLabelList
            // 
            this.btn_ModifyLabelList.Location = new System.Drawing.Point(15, 82);
            this.btn_ModifyLabelList.Name = "btn_ModifyLabelList";
            this.btn_ModifyLabelList.Size = new System.Drawing.Size(110, 25);
            this.btn_ModifyLabelList.TabIndex = 8;
            this.btn_ModifyLabelList.Text = "修改标签列表";
            this.btn_ModifyLabelList.UseVisualStyleBackColor = true;
            this.btn_ModifyLabelList.Click += new System.EventHandler(this.btn_ModifyLabelList_Click);
            // 
            // btn_AddLabel
            // 
            this.btn_AddLabel.Location = new System.Drawing.Point(13, 51);
            this.btn_AddLabel.Name = "btn_AddLabel";
            this.btn_AddLabel.Size = new System.Drawing.Size(112, 25);
            this.btn_AddLabel.TabIndex = 7;
            this.btn_AddLabel.Text = "新增标签";
            this.btn_AddLabel.UseVisualStyleBackColor = true;
            this.btn_AddLabel.Click += new System.EventHandler(this.btn_AddLabel_Click);
            // 
            // btn_GetLabelList
            // 
            this.btn_GetLabelList.Location = new System.Drawing.Point(13, 22);
            this.btn_GetLabelList.Name = "btn_GetLabelList";
            this.btn_GetLabelList.Size = new System.Drawing.Size(112, 23);
            this.btn_GetLabelList.TabIndex = 30;
            this.btn_GetLabelList.Text = "取标签列表";
            this.btn_GetLabelList.UseVisualStyleBackColor = true;
            this.btn_GetLabelList.Click += new System.EventHandler(this.btn_GetLabelList_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btn_shakeGet);
            this.groupBox6.Controls.Add(this.btn_lbsfind);
            this.groupBox6.Location = new System.Drawing.Point(313, 7);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(134, 101);
            this.groupBox6.TabIndex = 37;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "附近操作";
            // 
            // btn_shakeGet
            // 
            this.btn_shakeGet.Location = new System.Drawing.Point(9, 49);
            this.btn_shakeGet.Name = "btn_shakeGet";
            this.btn_shakeGet.Size = new System.Drawing.Size(109, 25);
            this.btn_shakeGet.TabIndex = 33;
            this.btn_shakeGet.Text = "摇一摇";
            this.btn_shakeGet.UseVisualStyleBackColor = true;
            this.btn_shakeGet.Click += new System.EventHandler(this.btn_shakeGet_Click);
            // 
            // btn_lbsfind
            // 
            this.btn_lbsfind.Location = new System.Drawing.Point(9, 20);
            this.btn_lbsfind.Name = "btn_lbsfind";
            this.btn_lbsfind.Size = new System.Drawing.Size(109, 23);
            this.btn_lbsfind.TabIndex = 27;
            this.btn_lbsfind.Text = "附近的人";
            this.btn_lbsfind.UseVisualStyleBackColor = true;
            this.btn_lbsfind.Click += new System.EventHandler(this.btn_lbsfind_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button4);
            this.groupBox4.Controls.Add(this.btn_SendCDnimg);
            this.groupBox4.Controls.Add(this.btn_downloadMsgimg);
            this.groupBox4.Controls.Add(this.btn_SendAppMsg);
            this.groupBox4.Controls.Add(this.btn_SendCardMsg);
            this.groupBox4.Controls.Add(this.btn_SendMsg);
            this.groupBox4.Controls.Add(this.btn_SendVoice);
            this.groupBox4.Controls.Add(this.btn_SendMsgimg);
            this.groupBox4.Location = new System.Drawing.Point(159, 7);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(140, 326);
            this.groupBox4.TabIndex = 36;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "信息操作";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(10, 229);
            this.button4.Name = "button4";
            this.button4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button4.Size = new System.Drawing.Size(113, 25);
            this.button4.TabIndex = 53;
            this.button4.Text = "发送视频";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btn_SendCDnimg
            // 
            this.btn_SendCDnimg.Location = new System.Drawing.Point(10, 198);
            this.btn_SendCDnimg.Name = "btn_SendCDnimg";
            this.btn_SendCDnimg.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_SendCDnimg.Size = new System.Drawing.Size(113, 25);
            this.btn_SendCDnimg.TabIndex = 52;
            this.btn_SendCDnimg.Text = "CDN发图";
            this.btn_SendCDnimg.UseVisualStyleBackColor = true;
            this.btn_SendCDnimg.Click += new System.EventHandler(this.btn_SendCDnimg_Click);
            // 
            // btn_downloadMsgimg
            // 
            this.btn_downloadMsgimg.Location = new System.Drawing.Point(11, 167);
            this.btn_downloadMsgimg.Name = "btn_downloadMsgimg";
            this.btn_downloadMsgimg.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_downloadMsgimg.Size = new System.Drawing.Size(112, 25);
            this.btn_downloadMsgimg.TabIndex = 51;
            this.btn_downloadMsgimg.Text = "接收高清大图";
            this.btn_downloadMsgimg.UseVisualStyleBackColor = true;
            this.btn_downloadMsgimg.Click += new System.EventHandler(this.btn_downloadMsgimg_Click);
            // 
            // btn_SendAppMsg
            // 
            this.btn_SendAppMsg.Location = new System.Drawing.Point(11, 136);
            this.btn_SendAppMsg.Name = "btn_SendAppMsg";
            this.btn_SendAppMsg.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_SendAppMsg.Size = new System.Drawing.Size(113, 25);
            this.btn_SendAppMsg.TabIndex = 50;
            this.btn_SendAppMsg.Text = "发送APP消息";
            this.btn_SendAppMsg.UseVisualStyleBackColor = false;
            this.btn_SendAppMsg.Click += new System.EventHandler(this.btn_SendAppMsg_Click);
            // 
            // btn_SendCardMsg
            // 
            this.btn_SendCardMsg.Location = new System.Drawing.Point(11, 105);
            this.btn_SendCardMsg.Name = "btn_SendCardMsg";
            this.btn_SendCardMsg.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_SendCardMsg.Size = new System.Drawing.Size(112, 25);
            this.btn_SendCardMsg.TabIndex = 49;
            this.btn_SendCardMsg.Text = "发送名片消息";
            this.btn_SendCardMsg.UseVisualStyleBackColor = true;
            this.btn_SendCardMsg.Click += new System.EventHandler(this.btn_SendCardMsg_Click);
            // 
            // btn_SendMsg
            // 
            this.btn_SendMsg.Location = new System.Drawing.Point(12, 76);
            this.btn_SendMsg.Name = "btn_SendMsg";
            this.btn_SendMsg.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_SendMsg.Size = new System.Drawing.Size(112, 25);
            this.btn_SendMsg.TabIndex = 48;
            this.btn_SendMsg.Text = "发送文本消息";
            this.btn_SendMsg.UseVisualStyleBackColor = true;
            this.btn_SendMsg.Click += new System.EventHandler(this.btn_SendMsg_Click);
            // 
            // btn_SendVoice
            // 
            this.btn_SendVoice.Location = new System.Drawing.Point(11, 48);
            this.btn_SendVoice.Name = "btn_SendVoice";
            this.btn_SendVoice.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_SendVoice.Size = new System.Drawing.Size(112, 23);
            this.btn_SendVoice.TabIndex = 46;
            this.btn_SendVoice.Text = "发送语音";
            this.btn_SendVoice.UseVisualStyleBackColor = true;
            this.btn_SendVoice.Click += new System.EventHandler(this.btn_SendVoice_Click);
            // 
            // btn_SendMsgimg
            // 
            this.btn_SendMsgimg.Location = new System.Drawing.Point(12, 18);
            this.btn_SendMsgimg.Name = "btn_SendMsgimg";
            this.btn_SendMsgimg.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_SendMsgimg.Size = new System.Drawing.Size(112, 23);
            this.btn_SendMsgimg.TabIndex = 47;
            this.btn_SendMsgimg.Text = "发送图片";
            this.btn_SendMsgimg.UseVisualStyleBackColor = true;
            this.btn_SendMsgimg.Click += new System.EventHandler(this.btn_SendMsgimg_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btn_SnsUpload);
            this.groupBox5.Controls.Add(this.btn_SnsSync);
            this.groupBox5.Controls.Add(this.btn_SnsPost);
            this.groupBox5.Controls.Add(this.btn_SnsObjectOp);
            this.groupBox5.Controls.Add(this.btn_SnsTimeLine);
            this.groupBox5.Controls.Add(this.btn_SnsUserPage);
            this.groupBox5.Location = new System.Drawing.Point(6, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(140, 229);
            this.groupBox5.TabIndex = 35;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "朋友圈操作";
            // 
            // btn_SnsUpload
            // 
            this.btn_SnsUpload.Location = new System.Drawing.Point(14, 165);
            this.btn_SnsUpload.Name = "btn_SnsUpload";
            this.btn_SnsUpload.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_SnsUpload.Size = new System.Drawing.Size(106, 25);
            this.btn_SnsUpload.TabIndex = 37;
            this.btn_SnsUpload.Text = "朋友圈上传图片";
            this.btn_SnsUpload.UseVisualStyleBackColor = true;
            this.btn_SnsUpload.Click += new System.EventHandler(this.btn_SnsUpload_Click);
            // 
            // btn_SnsSync
            // 
            this.btn_SnsSync.Location = new System.Drawing.Point(14, 136);
            this.btn_SnsSync.Name = "btn_SnsSync";
            this.btn_SnsSync.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_SnsSync.Size = new System.Drawing.Size(106, 23);
            this.btn_SnsSync.TabIndex = 36;
            this.btn_SnsSync.Text = "同步朋友圈";
            this.btn_SnsSync.UseVisualStyleBackColor = true;
            this.btn_SnsSync.Click += new System.EventHandler(this.btn_SnsSync_Click);
            // 
            // btn_SnsPost
            // 
            this.btn_SnsPost.Location = new System.Drawing.Point(14, 107);
            this.btn_SnsPost.Name = "btn_SnsPost";
            this.btn_SnsPost.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_SnsPost.Size = new System.Drawing.Size(106, 23);
            this.btn_SnsPost.TabIndex = 35;
            this.btn_SnsPost.Text = "发送朋友圈";
            this.btn_SnsPost.UseVisualStyleBackColor = true;
            this.btn_SnsPost.Click += new System.EventHandler(this.btn_SnsPost_Click);
            // 
            // btn_SnsObjectOp
            // 
            this.btn_SnsObjectOp.Location = new System.Drawing.Point(14, 78);
            this.btn_SnsObjectOp.Name = "btn_SnsObjectOp";
            this.btn_SnsObjectOp.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_SnsObjectOp.Size = new System.Drawing.Size(106, 23);
            this.btn_SnsObjectOp.TabIndex = 34;
            this.btn_SnsObjectOp.Text = "朋友圈操作";
            this.btn_SnsObjectOp.UseVisualStyleBackColor = true;
            this.btn_SnsObjectOp.Click += new System.EventHandler(this.btn_SnsObjectOp_Click);
            // 
            // btn_SnsTimeLine
            // 
            this.btn_SnsTimeLine.Location = new System.Drawing.Point(14, 49);
            this.btn_SnsTimeLine.Name = "btn_SnsTimeLine";
            this.btn_SnsTimeLine.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_SnsTimeLine.Size = new System.Drawing.Size(106, 23);
            this.btn_SnsTimeLine.TabIndex = 33;
            this.btn_SnsTimeLine.Text = "取朋友圈首页";
            this.btn_SnsTimeLine.UseVisualStyleBackColor = true;
            this.btn_SnsTimeLine.Click += new System.EventHandler(this.btn_SnsTimeLine_Click);
            // 
            // btn_SnsUserPage
            // 
            this.btn_SnsUserPage.Location = new System.Drawing.Point(14, 20);
            this.btn_SnsUserPage.Name = "btn_SnsUserPage";
            this.btn_SnsUserPage.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_SnsUserPage.Size = new System.Drawing.Size(106, 23);
            this.btn_SnsUserPage.TabIndex = 32;
            this.btn_SnsUserPage.Text = "取指定人盆友圈";
            this.btn_SnsUserPage.UseVisualStyleBackColor = true;
            this.btn_SnsUserPage.Click += new System.EventHandler(this.btn_SnsUserPage_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.btn_BindEail);
            this.groupBox1.Controls.Add(this.btn_GetContact);
            this.groupBox1.Controls.Add(this.btn_SearchContact);
            this.groupBox1.Controls.Add(this.btn_initcontact);
            this.groupBox1.Controls.Add(this.btn_get);
            this.groupBox1.Controls.Add(this.btn_GetA8Key);
            this.groupBox1.Location = new System.Drawing.Point(471, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(150, 302);
            this.groupBox1.TabIndex = 34;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "opt";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(16, 235);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(110, 23);
            this.button5.TabIndex = 48;
            this.button5.Text = "扫码进群";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // btn_BindEail
            // 
            this.btn_BindEail.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_BindEail.Location = new System.Drawing.Point(15, 204);
            this.btn_BindEail.Name = "btn_BindEail";
            this.btn_BindEail.Size = new System.Drawing.Size(112, 25);
            this.btn_BindEail.TabIndex = 47;
            this.btn_BindEail.Text = "绑定解绑邮箱";
            this.btn_BindEail.UseVisualStyleBackColor = true;
            this.btn_BindEail.Click += new System.EventHandler(this.btn_BindEail_Click);
            // 
            // btn_GetContact
            // 
            this.btn_GetContact.Location = new System.Drawing.Point(16, 173);
            this.btn_GetContact.Name = "btn_GetContact";
            this.btn_GetContact.Size = new System.Drawing.Size(112, 25);
            this.btn_GetContact.TabIndex = 45;
            this.btn_GetContact.Text = "搜索wxid";
            this.btn_GetContact.UseVisualStyleBackColor = true;
            this.btn_GetContact.Click += new System.EventHandler(this.btn_GetContact_Click);
            // 
            // btn_SearchContact
            // 
            this.btn_SearchContact.Location = new System.Drawing.Point(16, 144);
            this.btn_SearchContact.Name = "btn_SearchContact";
            this.btn_SearchContact.Size = new System.Drawing.Size(112, 23);
            this.btn_SearchContact.TabIndex = 44;
            this.btn_SearchContact.Text = "搜索QQ手机";
            this.btn_SearchContact.UseVisualStyleBackColor = true;
            this.btn_SearchContact.Click += new System.EventHandler(this.btn_SearchContact_Click);
            // 
            // btn_initcontact
            // 
            this.btn_initcontact.Location = new System.Drawing.Point(18, 107);
            this.btn_initcontact.Name = "btn_initcontact";
            this.btn_initcontact.Size = new System.Drawing.Size(110, 23);
            this.btn_initcontact.TabIndex = 43;
            this.btn_initcontact.Text = "拉取通讯录(精准)";
            this.btn_initcontact.UseVisualStyleBackColor = true;
            this.btn_initcontact.Click += new System.EventHandler(this.btn_initcontact_Click);
            // 
            // btn_get
            // 
            this.btn_get.Location = new System.Drawing.Point(19, 78);
            this.btn_get.Name = "btn_get";
            this.btn_get.Size = new System.Drawing.Size(109, 23);
            this.btn_get.TabIndex = 36;
            this.btn_get.Text = "取wxid二维码";
            this.btn_get.UseVisualStyleBackColor = true;
            this.btn_get.Click += new System.EventHandler(this.btn_get_Click);
            // 
            // btn_GetA8Key
            // 
            this.btn_GetA8Key.Location = new System.Drawing.Point(18, 49);
            this.btn_GetA8Key.Name = "btn_GetA8Key";
            this.btn_GetA8Key.Size = new System.Drawing.Size(110, 23);
            this.btn_GetA8Key.TabIndex = 35;
            this.btn_GetA8Key.Text = "授权阅读连接";
            this.btn_GetA8Key.UseVisualStyleBackColor = true;
            this.btn_GetA8Key.Click += new System.EventHandler(this.btn_GetA8Key_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox12);
            this.tabPage2.Controls.Add(this.groupBox15);
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(639, 385);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "好友操作";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.btn_UpMobile);
            this.groupBox12.Location = new System.Drawing.Point(489, 9);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(146, 359);
            this.groupBox12.TabIndex = 39;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "上传通讯录";
            // 
            // btn_UpMobile
            // 
            this.btn_UpMobile.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_UpMobile.Location = new System.Drawing.Point(6, 17);
            this.btn_UpMobile.Name = "btn_UpMobile";
            this.btn_UpMobile.Size = new System.Drawing.Size(130, 25);
            this.btn_UpMobile.TabIndex = 8;
            this.btn_UpMobile.Text = "上传通讯录";
            this.btn_UpMobile.UseVisualStyleBackColor = true;
            this.btn_UpMobile.Click += new System.EventHandler(this.btn_UpMobile_Click);
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.btn_AddFavItem);
            this.groupBox15.Controls.Add(this.btn_DelFavItem);
            this.groupBox15.Controls.Add(this.btn_GetFavItem);
            this.groupBox15.Controls.Add(this.btn_FavSync);
            this.groupBox15.Location = new System.Drawing.Point(338, 6);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(145, 362);
            this.groupBox15.TabIndex = 38;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "个人收藏操作";
            // 
            // btn_AddFavItem
            // 
            this.btn_AddFavItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_AddFavItem.Location = new System.Drawing.Point(6, 116);
            this.btn_AddFavItem.Name = "btn_AddFavItem";
            this.btn_AddFavItem.Size = new System.Drawing.Size(130, 25);
            this.btn_AddFavItem.TabIndex = 10;
            this.btn_AddFavItem.Text = "④添加单条收藏";
            this.btn_AddFavItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_AddFavItem.UseVisualStyleBackColor = true;
            this.btn_AddFavItem.Click += new System.EventHandler(this.btn_AddFavItem_Click);
            // 
            // btn_DelFavItem
            // 
            this.btn_DelFavItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_DelFavItem.Location = new System.Drawing.Point(6, 85);
            this.btn_DelFavItem.Name = "btn_DelFavItem";
            this.btn_DelFavItem.Size = new System.Drawing.Size(130, 25);
            this.btn_DelFavItem.TabIndex = 9;
            this.btn_DelFavItem.Text = "③删除单条收藏";
            this.btn_DelFavItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_DelFavItem.UseVisualStyleBackColor = true;
            this.btn_DelFavItem.Click += new System.EventHandler(this.btn_DelFavItem_Click);
            // 
            // btn_GetFavItem
            // 
            this.btn_GetFavItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_GetFavItem.Location = new System.Drawing.Point(6, 54);
            this.btn_GetFavItem.Name = "btn_GetFavItem";
            this.btn_GetFavItem.Size = new System.Drawing.Size(130, 25);
            this.btn_GetFavItem.TabIndex = 8;
            this.btn_GetFavItem.Text = "②获取单条收藏详细";
            this.btn_GetFavItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_GetFavItem.UseVisualStyleBackColor = true;
            this.btn_GetFavItem.Click += new System.EventHandler(this.btn_GetFavItem_Click);
            // 
            // btn_FavSync
            // 
            this.btn_FavSync.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_FavSync.Location = new System.Drawing.Point(6, 20);
            this.btn_FavSync.Name = "btn_FavSync";
            this.btn_FavSync.Size = new System.Drawing.Size(130, 25);
            this.btn_FavSync.TabIndex = 7;
            this.btn_FavSync.Text = "①同步个人收藏";
            this.btn_FavSync.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_FavSync.UseVisualStyleBackColor = true;
            this.btn_FavSync.Click += new System.EventHandler(this.btn_FavSync_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.button7);
            this.groupBox8.Controls.Add(this.btn_Add_Gh);
            this.groupBox8.Controls.Add(this.btn_SayHello);
            this.groupBox8.Controls.Add(this.btn_AcceptUser);
            this.groupBox8.Controls.Add(this.btn_AddUser);
            this.groupBox8.Location = new System.Drawing.Point(176, 6);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(145, 362);
            this.groupBox8.TabIndex = 37;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "好友/公众号操作";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(6, 144);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(130, 25);
            this.button7.TabIndex = 10;
            this.button7.Text = "获取好友详细";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // btn_Add_Gh
            // 
            this.btn_Add_Gh.Location = new System.Drawing.Point(6, 113);
            this.btn_Add_Gh.Name = "btn_Add_Gh";
            this.btn_Add_Gh.Size = new System.Drawing.Size(130, 25);
            this.btn_Add_Gh.TabIndex = 9;
            this.btn_Add_Gh.Text = "关注公众号";
            this.btn_Add_Gh.UseVisualStyleBackColor = true;
            this.btn_Add_Gh.Click += new System.EventHandler(this.btn_Add_Gh_Click);
            // 
            // btn_SayHello
            // 
            this.btn_SayHello.Location = new System.Drawing.Point(6, 82);
            this.btn_SayHello.Name = "btn_SayHello";
            this.btn_SayHello.Size = new System.Drawing.Size(130, 25);
            this.btn_SayHello.TabIndex = 8;
            this.btn_SayHello.Text = "发起打招呼";
            this.btn_SayHello.UseVisualStyleBackColor = true;
            this.btn_SayHello.Click += new System.EventHandler(this.btn_SayHello_Click);
            // 
            // btn_AcceptUser
            // 
            this.btn_AcceptUser.Location = new System.Drawing.Point(6, 51);
            this.btn_AcceptUser.Name = "btn_AcceptUser";
            this.btn_AcceptUser.Size = new System.Drawing.Size(130, 25);
            this.btn_AcceptUser.TabIndex = 7;
            this.btn_AcceptUser.Text = "接受好友请求";
            this.btn_AcceptUser.UseVisualStyleBackColor = true;
            this.btn_AcceptUser.Click += new System.EventHandler(this.btn_AcceptUser_Click);
            // 
            // btn_AddUser
            // 
            this.btn_AddUser.Location = new System.Drawing.Point(6, 20);
            this.btn_AddUser.Name = "btn_AddUser";
            this.btn_AddUser.Size = new System.Drawing.Size(130, 25);
            this.btn_AddUser.TabIndex = 6;
            this.btn_AddUser.Text = "添加用户";
            this.btn_AddUser.UseVisualStyleBackColor = true;
            this.btn_AddUser.Click += new System.EventHandler(this.btn_AddUser_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_SetChatRoomAnnouncement);
            this.groupBox2.Controls.Add(this.btn_GetRoomDetail);
            this.groupBox2.Controls.Add(this.btn_DelChatRoomUser);
            this.groupBox2.Controls.Add(this.btn_AddChatRoomMember);
            this.groupBox2.Controls.Add(this.btn_CreateChatRoom);
            this.groupBox2.Location = new System.Drawing.Point(15, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(146, 362);
            this.groupBox2.TabIndex = 36;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "group";
            // 
            // btn_SetChatRoomAnnouncement
            // 
            this.btn_SetChatRoomAnnouncement.Location = new System.Drawing.Point(6, 135);
            this.btn_SetChatRoomAnnouncement.Name = "btn_SetChatRoomAnnouncement";
            this.btn_SetChatRoomAnnouncement.Size = new System.Drawing.Size(134, 25);
            this.btn_SetChatRoomAnnouncement.TabIndex = 33;
            this.btn_SetChatRoomAnnouncement.Text = "修改群公告";
            this.btn_SetChatRoomAnnouncement.UseVisualStyleBackColor = true;
            this.btn_SetChatRoomAnnouncement.Click += new System.EventHandler(this.btn_SetChatRoomAnnouncement_Click);
            // 
            // btn_GetRoomDetail
            // 
            this.btn_GetRoomDetail.Location = new System.Drawing.Point(7, 106);
            this.btn_GetRoomDetail.Name = "btn_GetRoomDetail";
            this.btn_GetRoomDetail.Size = new System.Drawing.Size(133, 23);
            this.btn_GetRoomDetail.TabIndex = 32;
            this.btn_GetRoomDetail.Text = "取群成员详细";
            this.btn_GetRoomDetail.UseVisualStyleBackColor = true;
            this.btn_GetRoomDetail.Click += new System.EventHandler(this.btn_GetRoomDetail_Click);
            // 
            // btn_DelChatRoomUser
            // 
            this.btn_DelChatRoomUser.Location = new System.Drawing.Point(7, 77);
            this.btn_DelChatRoomUser.Name = "btn_DelChatRoomUser";
            this.btn_DelChatRoomUser.Size = new System.Drawing.Size(133, 23);
            this.btn_DelChatRoomUser.TabIndex = 31;
            this.btn_DelChatRoomUser.Text = "删除群成员";
            this.btn_DelChatRoomUser.UseVisualStyleBackColor = true;
            this.btn_DelChatRoomUser.Click += new System.EventHandler(this.btn_DelChatRoomUser_Click);
            // 
            // btn_AddChatRoomMember
            // 
            this.btn_AddChatRoomMember.Location = new System.Drawing.Point(7, 49);
            this.btn_AddChatRoomMember.Name = "btn_AddChatRoomMember";
            this.btn_AddChatRoomMember.Size = new System.Drawing.Size(133, 23);
            this.btn_AddChatRoomMember.TabIndex = 30;
            this.btn_AddChatRoomMember.Text = "邀请好友";
            this.btn_AddChatRoomMember.UseVisualStyleBackColor = true;
            this.btn_AddChatRoomMember.Click += new System.EventHandler(this.btn_AddChatRoomMember_Click);
            // 
            // btn_CreateChatRoom
            // 
            this.btn_CreateChatRoom.Location = new System.Drawing.Point(7, 20);
            this.btn_CreateChatRoom.Name = "btn_CreateChatRoom";
            this.btn_CreateChatRoom.Size = new System.Drawing.Size(133, 23);
            this.btn_CreateChatRoom.TabIndex = 29;
            this.btn_CreateChatRoom.Text = "创建群";
            this.btn_CreateChatRoom.UseVisualStyleBackColor = true;
            this.btn_CreateChatRoom.Click += new System.EventHandler(this.btn_CreateChatRoom_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox11);
            this.tabPage3.Controls.Add(this.groupBox20);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(639, 385);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "支付类";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.btn_TenPay_TransferConfirm);
            this.groupBox11.Controls.Add(this.btn_TransferReq);
            this.groupBox11.Controls.Add(this.btn_GenPreTransferReq);
            this.groupBox11.Location = new System.Drawing.Point(159, 6);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(145, 115);
            this.groupBox11.TabIndex = 23;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "转账";
            // 
            // btn_TenPay_TransferConfirm
            // 
            this.btn_TenPay_TransferConfirm.Location = new System.Drawing.Point(6, 82);
            this.btn_TenPay_TransferConfirm.Name = "btn_TenPay_TransferConfirm";
            this.btn_TenPay_TransferConfirm.Size = new System.Drawing.Size(130, 25);
            this.btn_TenPay_TransferConfirm.TabIndex = 8;
            this.btn_TenPay_TransferConfirm.Text = "确认收款";
            this.btn_TenPay_TransferConfirm.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_TenPay_TransferConfirm.UseVisualStyleBackColor = true;
            this.btn_TenPay_TransferConfirm.Click += new System.EventHandler(this.btn_TenPay_TransferConfirm_Click);
            // 
            // btn_TransferReq
            // 
            this.btn_TransferReq.Location = new System.Drawing.Point(6, 51);
            this.btn_TransferReq.Name = "btn_TransferReq";
            this.btn_TransferReq.Size = new System.Drawing.Size(130, 25);
            this.btn_TransferReq.TabIndex = 7;
            this.btn_TransferReq.Text = "②支付转账";
            this.btn_TransferReq.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_TransferReq.UseVisualStyleBackColor = true;
            this.btn_TransferReq.Click += new System.EventHandler(this.btn_TransferReq_Click);
            // 
            // btn_GenPreTransferReq
            // 
            this.btn_GenPreTransferReq.Location = new System.Drawing.Point(6, 20);
            this.btn_GenPreTransferReq.Name = "btn_GenPreTransferReq";
            this.btn_GenPreTransferReq.Size = new System.Drawing.Size(130, 25);
            this.btn_GenPreTransferReq.TabIndex = 6;
            this.btn_GenPreTransferReq.Text = "①创建转账";
            this.btn_GenPreTransferReq.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_GenPreTransferReq.UseVisualStyleBackColor = true;
            this.btn_GenPreTransferReq.Click += new System.EventHandler(this.btn_GenPreTransferReq_Click);
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.btn_Fetchauthen);
            this.groupBox20.Controls.Add(this.btn_GetBalance);
            this.groupBox20.Controls.Add(this.btn_Genprefetch);
            this.groupBox20.Controls.Add(this.btn_GetBlankID);
            this.groupBox20.Controls.Add(this.btn_F2ffee);
            this.groupBox20.Location = new System.Drawing.Point(8, 6);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(145, 180);
            this.groupBox20.TabIndex = 22;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "钱包";
            this.groupBox20.Enter += new System.EventHandler(this.groupBox20_Enter);
            // 
            // btn_Fetchauthen
            // 
            this.btn_Fetchauthen.Enabled = false;
            this.btn_Fetchauthen.Location = new System.Drawing.Point(6, 144);
            this.btn_Fetchauthen.Name = "btn_Fetchauthen";
            this.btn_Fetchauthen.Size = new System.Drawing.Size(130, 25);
            this.btn_Fetchauthen.TabIndex = 18;
            this.btn_Fetchauthen.Text = "②确认提现";
            this.btn_Fetchauthen.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Fetchauthen.UseVisualStyleBackColor = true;
            // 
            // btn_GetBalance
            // 
            this.btn_GetBalance.Location = new System.Drawing.Point(6, 20);
            this.btn_GetBalance.Name = "btn_GetBalance";
            this.btn_GetBalance.Size = new System.Drawing.Size(130, 25);
            this.btn_GetBalance.TabIndex = 16;
            this.btn_GetBalance.Text = "获取余额及绑卡信息";
            this.btn_GetBalance.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_GetBalance.UseVisualStyleBackColor = true;
            this.btn_GetBalance.Click += new System.EventHandler(this.btn_GetBalance_Click_1);
            // 
            // btn_Genprefetch
            // 
            this.btn_Genprefetch.Enabled = false;
            this.btn_Genprefetch.Location = new System.Drawing.Point(6, 113);
            this.btn_Genprefetch.Name = "btn_Genprefetch";
            this.btn_Genprefetch.Size = new System.Drawing.Size(130, 25);
            this.btn_Genprefetch.TabIndex = 17;
            this.btn_Genprefetch.Text = "①创建提现订单";
            this.btn_Genprefetch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Genprefetch.UseVisualStyleBackColor = true;
            // 
            // btn_GetBlankID
            // 
            this.btn_GetBlankID.Location = new System.Drawing.Point(6, 82);
            this.btn_GetBlankID.Name = "btn_GetBlankID";
            this.btn_GetBlankID.Size = new System.Drawing.Size(130, 25);
            this.btn_GetBlankID.TabIndex = 12;
            this.btn_GetBlankID.Text = "获取银行卡ID";
            this.btn_GetBlankID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_GetBlankID.UseVisualStyleBackColor = true;
            // 
            // btn_F2ffee
            // 
            this.btn_F2ffee.Location = new System.Drawing.Point(6, 51);
            this.btn_F2ffee.Name = "btn_F2ffee";
            this.btn_F2ffee.Size = new System.Drawing.Size(130, 25);
            this.btn_F2ffee.TabIndex = 17;
            this.btn_F2ffee.Text = "自定义生成金额二维码";
            this.btn_F2ffee.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_F2ffee.UseVisualStyleBackColor = true;
            this.btn_F2ffee.Click += new System.EventHandler(this.btn_F2ffee_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox10);
            this.tabPage4.Controls.Add(this.groupBox16);
            this.tabPage4.Controls.Add(this.groupBox9);
            this.tabPage4.Controls.Add(this.groupBox18);
            this.tabPage4.Controls.Add(this.groupBox13);
            this.tabPage4.Controls.Add(this.groupBox19);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(639, 385);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "功能操作";
            this.tabPage4.UseVisualStyleBackColor = true;
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.button8);
            this.groupBox10.Controls.Add(this.btn_Bindmolie_yzcode);
            this.groupBox10.Controls.Add(this.btn_BindMobile_getcode);
            this.groupBox10.Location = new System.Drawing.Point(186, 234);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(145, 134);
            this.groupBox10.TabIndex = 61;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "绑定号码";
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(9, 81);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(130, 25);
            this.button8.TabIndex = 57;
            this.button8.Text = "解绑手机号";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // btn_Bindmolie_yzcode
            // 
            this.btn_Bindmolie_yzcode.Location = new System.Drawing.Point(9, 50);
            this.btn_Bindmolie_yzcode.Name = "btn_Bindmolie_yzcode";
            this.btn_Bindmolie_yzcode.Size = new System.Drawing.Size(130, 25);
            this.btn_Bindmolie_yzcode.TabIndex = 56;
            this.btn_Bindmolie_yzcode.Text = "绑定手机号";
            this.btn_Bindmolie_yzcode.UseVisualStyleBackColor = true;
            this.btn_Bindmolie_yzcode.Click += new System.EventHandler(this.btn_Bindmolie_yzcode_Click);
            // 
            // btn_BindMobile_getcode
            // 
            this.btn_BindMobile_getcode.Location = new System.Drawing.Point(9, 20);
            this.btn_BindMobile_getcode.Name = "btn_BindMobile_getcode";
            this.btn_BindMobile_getcode.Size = new System.Drawing.Size(130, 25);
            this.btn_BindMobile_getcode.TabIndex = 55;
            this.btn_BindMobile_getcode.Text = "获取验证码";
            this.btn_BindMobile_getcode.UseVisualStyleBackColor = true;
            this.btn_BindMobile_getcode.Click += new System.EventHandler(this.btn_BindMobile_getcode_Click);
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.btn_setPwd);
            this.groupBox16.Controls.Add(this.btn_verifyPwd);
            this.groupBox16.Location = new System.Drawing.Point(15, 234);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(145, 85);
            this.groupBox16.TabIndex = 60;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "修改密码";
            // 
            // btn_setPwd
            // 
            this.btn_setPwd.Location = new System.Drawing.Point(6, 51);
            this.btn_setPwd.Name = "btn_setPwd";
            this.btn_setPwd.Size = new System.Drawing.Size(130, 25);
            this.btn_setPwd.TabIndex = 7;
            this.btn_setPwd.Text = "修改密码";
            this.btn_setPwd.UseVisualStyleBackColor = true;
            this.btn_setPwd.Click += new System.EventHandler(this.btn_setPwd_Click);
            // 
            // btn_verifyPwd
            // 
            this.btn_verifyPwd.Location = new System.Drawing.Point(6, 20);
            this.btn_verifyPwd.Name = "btn_verifyPwd";
            this.btn_verifyPwd.Size = new System.Drawing.Size(130, 25);
            this.btn_verifyPwd.TabIndex = 6;
            this.btn_verifyPwd.Text = "验证密码";
            this.btn_verifyPwd.UseVisualStyleBackColor = true;
            this.btn_verifyPwd.Click += new System.EventHandler(this.btn_verifyPwd_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.Btn_DataLogin);
            this.groupBox9.Location = new System.Drawing.Point(498, 11);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(130, 183);
            this.groupBox9.TabIndex = 59;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "登录";
            // 
            // Btn_DataLogin
            // 
            this.Btn_DataLogin.Location = new System.Drawing.Point(6, 23);
            this.Btn_DataLogin.Name = "Btn_DataLogin";
            this.Btn_DataLogin.Size = new System.Drawing.Size(120, 25);
            this.Btn_DataLogin.TabIndex = 55;
            this.Btn_DataLogin.Text = "62数据登录";
            this.Btn_DataLogin.UseVisualStyleBackColor = true;
            this.Btn_DataLogin.Click += new System.EventHandler(this.Btn_DataLogin_Click);
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.button6);
            this.groupBox18.Controls.Add(this.btn_ZC);
            this.groupBox18.Controls.Add(this.btn_NewReg);
            this.groupBox18.Controls.Add(this.btn_ChackSmsCode);
            this.groupBox18.Controls.Add(this.btn_GetSms);
            this.groupBox18.Location = new System.Drawing.Point(347, 12);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(145, 182);
            this.groupBox18.TabIndex = 58;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "注册/验证";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(9, 114);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(130, 25);
            this.button6.TabIndex = 58;
            this.button6.Text = "验证短信验证码";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // btn_ZC
            // 
            this.btn_ZC.Location = new System.Drawing.Point(9, 53);
            this.btn_ZC.Name = "btn_ZC";
            this.btn_ZC.Size = new System.Drawing.Size(130, 25);
            this.btn_ZC.TabIndex = 57;
            this.btn_ZC.Text = "获取zc码";
            this.btn_ZC.UseVisualStyleBackColor = true;
            this.btn_ZC.Click += new System.EventHandler(this.btn_ZC_Click);
            // 
            // btn_NewReg
            // 
            this.btn_NewReg.Location = new System.Drawing.Point(9, 144);
            this.btn_NewReg.Name = "btn_NewReg";
            this.btn_NewReg.Size = new System.Drawing.Size(130, 25);
            this.btn_NewReg.TabIndex = 56;
            this.btn_NewReg.Text = "注册";
            this.btn_NewReg.UseVisualStyleBackColor = true;
            this.btn_NewReg.Click += new System.EventHandler(this.btn_NewReg_Click);
            // 
            // btn_ChackSmsCode
            // 
            this.btn_ChackSmsCode.Location = new System.Drawing.Point(9, 83);
            this.btn_ChackSmsCode.Name = "btn_ChackSmsCode";
            this.btn_ChackSmsCode.Size = new System.Drawing.Size(130, 25);
            this.btn_ChackSmsCode.TabIndex = 55;
            this.btn_ChackSmsCode.Text = "已发送短信";
            this.btn_ChackSmsCode.UseVisualStyleBackColor = true;
            this.btn_ChackSmsCode.Click += new System.EventHandler(this.btn_ChackSmsCode_Click);
            // 
            // btn_GetSms
            // 
            this.btn_GetSms.Location = new System.Drawing.Point(9, 22);
            this.btn_GetSms.Name = "btn_GetSms";
            this.btn_GetSms.Size = new System.Drawing.Size(130, 25);
            this.btn_GetSms.TabIndex = 54;
            this.btn_GetSms.Text = "获取滑块";
            this.btn_GetSms.UseVisualStyleBackColor = true;
            this.btn_GetSms.Click += new System.EventHandler(this.btn_GetSms_Click);
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.btn_deviceLogins);
            this.groupBox13.Controls.Add(this.btn_loginBySms);
            this.groupBox13.Controls.Add(this.button3);
            this.groupBox13.Controls.Add(this.btn_logoutweb);
            this.groupBox13.Controls.Add(this.btn_GetLoginSmsCodes);
            this.groupBox13.Controls.Add(this.btn_PushUrlLogin);
            this.groupBox13.Location = new System.Drawing.Point(186, 12);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(145, 210);
            this.groupBox13.TabIndex = 57;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "其他方式登录";
            this.groupBox13.Enter += new System.EventHandler(this.groupBox13_Enter);
            // 
            // btn_deviceLogins
            // 
            this.btn_deviceLogins.Location = new System.Drawing.Point(6, 174);
            this.btn_deviceLogins.Name = "btn_deviceLogins";
            this.btn_deviceLogins.Size = new System.Drawing.Size(130, 25);
            this.btn_deviceLogins.TabIndex = 52;
            this.btn_deviceLogins.Text = "多终端登陆";
            this.btn_deviceLogins.UseVisualStyleBackColor = true;
            this.btn_deviceLogins.Click += new System.EventHandler(this.btn_deviceLogins_Click);
            // 
            // btn_loginBySms
            // 
            this.btn_loginBySms.Location = new System.Drawing.Point(6, 82);
            this.btn_loginBySms.Name = "btn_loginBySms";
            this.btn_loginBySms.Size = new System.Drawing.Size(130, 25);
            this.btn_loginBySms.TabIndex = 42;
            this.btn_loginBySms.Text = "确认登陆";
            this.btn_loginBySms.UseVisualStyleBackColor = true;
            this.btn_loginBySms.Click += new System.EventHandler(this.btn_loginBySms_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(6, 51);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(130, 25);
            this.button3.TabIndex = 41;
            this.button3.Text = "验证登陆短信";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_logoutweb
            // 
            this.btn_logoutweb.Location = new System.Drawing.Point(6, 144);
            this.btn_logoutweb.Name = "btn_logoutweb";
            this.btn_logoutweb.Size = new System.Drawing.Size(130, 25);
            this.btn_logoutweb.TabIndex = 50;
            this.btn_logoutweb.Text = "退出IPad端/PC端网页端微信";
            this.btn_logoutweb.UseVisualStyleBackColor = true;
            this.btn_logoutweb.Click += new System.EventHandler(this.btn_logoutweb_Click);
            // 
            // btn_GetLoginSmsCodes
            // 
            this.btn_GetLoginSmsCodes.Location = new System.Drawing.Point(6, 20);
            this.btn_GetLoginSmsCodes.Name = "btn_GetLoginSmsCodes";
            this.btn_GetLoginSmsCodes.Size = new System.Drawing.Size(130, 25);
            this.btn_GetLoginSmsCodes.TabIndex = 40;
            this.btn_GetLoginSmsCodes.Text = "获取登陆短信";
            this.btn_GetLoginSmsCodes.UseVisualStyleBackColor = true;
            this.btn_GetLoginSmsCodes.Click += new System.EventHandler(this.btn_GetLoginSmsCodes_Click);
            // 
            // btn_PushUrlLogin
            // 
            this.btn_PushUrlLogin.Location = new System.Drawing.Point(6, 113);
            this.btn_PushUrlLogin.Name = "btn_PushUrlLogin";
            this.btn_PushUrlLogin.Size = new System.Drawing.Size(130, 25);
            this.btn_PushUrlLogin.TabIndex = 46;
            this.btn_PushUrlLogin.Text = "手机登陆";
            this.btn_PushUrlLogin.UseVisualStyleBackColor = true;
            this.btn_PushUrlLogin.Click += new System.EventHandler(this.btn_PushUrlLogin_Click);
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.btn_logout);
            this.groupBox19.Controls.Add(this.btn_SyncCheck);
            this.groupBox19.Controls.Add(this.btn_AutoAuth);
            this.groupBox19.Controls.Add(this.btn_Sync);
            this.groupBox19.Controls.Add(this.btn_NewInit);
            this.groupBox19.Controls.Add(this.button2);
            this.groupBox19.Location = new System.Drawing.Point(15, 12);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(145, 205);
            this.groupBox19.TabIndex = 56;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "基本功能";
            // 
            // btn_logout
            // 
            this.btn_logout.Location = new System.Drawing.Point(6, 144);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(130, 25);
            this.btn_logout.TabIndex = 51;
            this.btn_logout.Text = "退出登录";
            this.btn_logout.UseVisualStyleBackColor = true;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // btn_SyncCheck
            // 
            this.btn_SyncCheck.Location = new System.Drawing.Point(6, 82);
            this.btn_SyncCheck.Name = "btn_SyncCheck";
            this.btn_SyncCheck.Size = new System.Drawing.Size(130, 25);
            this.btn_SyncCheck.TabIndex = 49;
            this.btn_SyncCheck.Text = "心跳包";
            this.btn_SyncCheck.UseVisualStyleBackColor = true;
            this.btn_SyncCheck.Click += new System.EventHandler(this.btn_SyncCheck_Click);
            // 
            // btn_AutoAuth
            // 
            this.btn_AutoAuth.Location = new System.Drawing.Point(6, 174);
            this.btn_AutoAuth.Name = "btn_AutoAuth";
            this.btn_AutoAuth.Size = new System.Drawing.Size(130, 25);
            this.btn_AutoAuth.TabIndex = 48;
            this.btn_AutoAuth.Text = "二次登陆";
            this.btn_AutoAuth.UseVisualStyleBackColor = true;
            this.btn_AutoAuth.Click += new System.EventHandler(this.btn_AutoAuth_Click);
            // 
            // btn_Sync
            // 
            this.btn_Sync.Location = new System.Drawing.Point(6, 51);
            this.btn_Sync.Name = "btn_Sync";
            this.btn_Sync.Size = new System.Drawing.Size(130, 25);
            this.btn_Sync.TabIndex = 47;
            this.btn_Sync.Text = "Sync同步消息";
            this.btn_Sync.UseVisualStyleBackColor = true;
            this.btn_Sync.Click += new System.EventHandler(this.btn_Sync_Click);
            // 
            // btn_NewInit
            // 
            this.btn_NewInit.Location = new System.Drawing.Point(6, 20);
            this.btn_NewInit.Name = "btn_NewInit";
            this.btn_NewInit.Size = new System.Drawing.Size(130, 25);
            this.btn_NewInit.TabIndex = 46;
            this.btn_NewInit.Text = "NewInit初始化";
            this.btn_NewInit.UseVisualStyleBackColor = true;
            this.btn_NewInit.Click += new System.EventHandler(this.btn_NewInit_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(6, 113);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(130, 25);
            this.button2.TabIndex = 40;
            this.button2.Text = "拉取通讯录(精准)";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(184, 139);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 12);
            this.label4.TabIndex = 42;
            this.label4.Text = "AtUserLists:";
            // 
            // tb_AtUserlist
            // 
            this.tb_AtUserlist.Location = new System.Drawing.Point(267, 139);
            this.tb_AtUserlist.Name = "tb_AtUserlist";
            this.tb_AtUserlist.Size = new System.Drawing.Size(232, 21);
            this.tb_AtUserlist.TabIndex = 41;
            this.tb_AtUserlist.Text = "jp2799376";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(516, 82);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 21);
            this.textBox1.TabIndex = 43;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(960, 578);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tb_AtUserlist);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tb_ToUsername);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tb_Content);
            this.Controls.Add(this.btn_GetQrcode);
            this.Controls.Add(this.pB_Qrcode);
            this.Controls.Add(this.groupBox3);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pB_Qrcode)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox20.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox16.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_GetQrcode;
        private System.Windows.Forms.PictureBox pB_Qrcode;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RichTextBox rtb_Msg;
        private System.Windows.Forms.TextBox tb_Content;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_ToUsername;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btn_lbsfind;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btn_SendVoice;
        private System.Windows.Forms.Button btn_SendMsgimg;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btn_SnsPost;
        private System.Windows.Forms.Button btn_SnsObjectOp;
        private System.Windows.Forms.Button btn_SnsTimeLine;
        private System.Windows.Forms.Button btn_SnsUserPage;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_SearchContact;
        private System.Windows.Forms.Button btn_initcontact;
        private System.Windows.Forms.Button btn_get;
        private System.Windows.Forms.Button btn_GetA8Key;
        private System.Windows.Forms.Button btn_GetLabelList;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_GetRoomDetail;
        private System.Windows.Forms.Button btn_DelChatRoomUser;
        private System.Windows.Forms.Button btn_AddChatRoomMember;
        private System.Windows.Forms.Button btn_CreateChatRoom;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.Button btn_Fetchauthen;
        private System.Windows.Forms.Button btn_GetBalance;
        private System.Windows.Forms.Button btn_Genprefetch;
        private System.Windows.Forms.Button btn_GetBlankID;
        private System.Windows.Forms.Button btn_F2ffee;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button btn_TenPay_TransferConfirm;
        private System.Windows.Forms.Button btn_TransferReq;
        private System.Windows.Forms.Button btn_GenPreTransferReq;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_AtUserlist;
        private System.Windows.Forms.Button btn_shakeGet;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.Button btn_logout;
        private System.Windows.Forms.Button btn_SyncCheck;
        private System.Windows.Forms.Button btn_AutoAuth;
        private System.Windows.Forms.Button btn_Sync;
        private System.Windows.Forms.Button btn_NewInit;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btn_SnsSync;
        private System.Windows.Forms.Button btn_GetContact;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Button btn_AddFavItem;
        private System.Windows.Forms.Button btn_DelFavItem;
        private System.Windows.Forms.Button btn_GetFavItem;
        private System.Windows.Forms.Button btn_FavSync;
        private System.Windows.Forms.Button btn_SendMsg;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button btn_ModifyLabelList;
        private System.Windows.Forms.Button btn_AddLabel;
        private System.Windows.Forms.Button btn_DelContactLabel;
        private System.Windows.Forms.Button btn_SnsUpload;
        private System.Windows.Forms.Button btn_SendCardMsg;
        private System.Windows.Forms.Button btn_SendAppMsg;
        private System.Windows.Forms.Button btn_SetChatRoomAnnouncement;
        private System.Windows.Forms.Button btn_downloadMsgimg;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btn_BindEail;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Button btn_deviceLogins;
        private System.Windows.Forms.Button btn_loginBySms;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btn_logoutweb;
        private System.Windows.Forms.Button btn_GetLoginSmsCodes;
        private System.Windows.Forms.Button btn_PushUrlLogin;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Button btn_ZC;
        private System.Windows.Forms.Button btn_NewReg;
        private System.Windows.Forms.Button btn_ChackSmsCode;
        private System.Windows.Forms.Button btn_SendCDnimg;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button Btn_DataLogin;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Button btn_setPwd;
        private System.Windows.Forms.Button btn_verifyPwd;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button btn_Add_Gh;
        private System.Windows.Forms.Button btn_SayHello;
        private System.Windows.Forms.Button btn_AcceptUser;
        private System.Windows.Forms.Button btn_AddUser;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button btn_BindMobile_getcode;
        private System.Windows.Forms.Button btn_GetSms;
        private System.Windows.Forms.Button btn_Bindmolie_yzcode;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button btn_UpMobile;
    }
}

